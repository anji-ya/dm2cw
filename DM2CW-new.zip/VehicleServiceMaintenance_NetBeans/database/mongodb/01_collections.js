// Run in mongosh.
// Database: vehicle_service

use vehicle_service

db.createCollection("vehicle_job_cards", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["vehicle_id", "registration_no", "job_status", "opened_at"],
      properties: {
        vehicle_id: {bsonType: "int"},
        registration_no: {bsonType: "string"},
        technician: {bsonType: "string"},
        job_status: {enum: ["OPEN","IN_PROGRESS","COMPLETED","CANCELLED"]},
        opened_at: {bsonType: "string"}
      }
    }
  }
})

db.createCollection("technician_notes", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["vehicle_id", "technician", "note", "created_at"],
      properties: {
        vehicle_id: {bsonType: "int"},
        technician: {bsonType: "string"},
        note: {bsonType: "string"},
        created_at: {bsonType: "string"}
      }
    }
  }
})

db.createCollection("service_history_logs")
db.createCollection("customer_complaints")
db.createCollection("diagnostic_summaries")

db.vehicle_job_cards.insertMany([
  {
    vehicle_id: 1, registration_no: "CBA-1234", technician: "Kasun Silva",
    job_status: "COMPLETED", opened_at: "2026-08-12T09:00:00Z",
    work_summary: "Full service completed; brake inspection performed."
  },
  {
    vehicle_id: 2, registration_no: "KJ-4521", technician: "Amal Perera",
    job_status: "OPEN", opened_at: "2026-08-20T10:30:00Z",
    work_summary: "Oil and filter check scheduled."
  }
])

db.technician_notes.insertOne({
  vehicle_id: 1, registration_no: "CBA-1234", technician: "Kasun Silva",
  note: "Brake pads have acceptable thickness. Recommend inspection at next service.",
  created_at: "2026-08-12T11:30:00Z"
})

db.service_history_logs.insertOne({
  vehicle_id: 1, registration_no: "CBA-1234",
  service_type: "Full Service", mileage: 68500,
  performed_at: "2026-08-12T12:00:00Z",
  parts_used: ["FLT-001"], total_cost: 21830
})

db.customer_complaints.insertOne({
  vehicle_id: 2, registration_no: "KJ-4521",
  customer_id: 2, complaint_type: "SERVICE_DELAY",
  description: "Customer requested faster service updates.",
  priority: "MEDIUM", status: "OPEN",
  created_at: "2026-08-13T08:00:00Z"
})

db.diagnostic_summaries.insertOne({
  vehicle_id: 3, registration_no: "WP-CAB-7788",
  scan_type: "EV_DIAGNOSTIC", result: "NO_CRITICAL_FAULTS",
  battery_health: 91, warnings: [],
  scanned_at: "2026-08-10T15:20:00Z"
})
