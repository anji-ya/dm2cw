-- Realistic sample data.
INSERT INTO customers(first_name,last_name,phone,email,address) VALUES
('Kavindu','Perera','0771234567','kavindu@example.com','Kandy');
INSERT INTO customers(first_name,last_name,phone,email,address) VALUES
('Dhilshika','Rasalingam','0712345678','dhilshika@example.com','Kandy');
INSERT INTO customers(first_name,last_name,phone,email,address) VALUES
('Nimal','Fernando','0755555555','nimal@example.com','Colombo');

INSERT INTO vehicles(registration_no,customer_id,make,model,model_year,mileage,fuel_type)
VALUES('CBA-1234',1,'Toyota','Corolla',2018,68500,'PETROL');
INSERT INTO vehicles(registration_no,customer_id,make,model,model_year,mileage,fuel_type)
VALUES('KJ-4521',2,'Honda','Vezel',2020,43200,'HYBRID');
INSERT INTO vehicles(registration_no,customer_id,make,model,model_year,mileage,fuel_type)
VALUES('WP-CAB-7788',3,'Nissan','Leaf',2021,28500,'ELECTRIC');

INSERT INTO service_bookings(vehicle_id,booking_date,booking_time,service_type,status,estimated_cost)
VALUES(1,DATE '2026-08-12','09:00','Full Service','COMPLETED',18500);
INSERT INTO service_bookings(vehicle_id,booking_date,booking_time,service_type,status,estimated_cost)
VALUES(2,DATE '2026-08-20','10:30','Oil & Filter Check','CONFIRMED',12000);
INSERT INTO service_bookings(vehicle_id,booking_date,booking_time,service_type,status,estimated_cost)
VALUES(3,DATE '2026-08-22','14:00','EV Diagnostic','BOOKED',9500);

INSERT INTO invoices(booking_id,subtotal,tax,payment_status,payment_method)
VALUES(1,18500,3330,'PAID','CARD');

INSERT INTO spare_parts(part_code,part_name,category,quantity_in_stock,reorder_level,unit_price,supplier)
VALUES('BRK-001','Front Brake Pad Set','Brakes',18,5,12500,'Auto Parts Lanka');
INSERT INTO spare_parts(part_code,part_name,category,quantity_in_stock,reorder_level,unit_price,supplier)
VALUES('FLT-001','Oil Filter','Filters',42,10,2200,'Motor Spares Kandy');
INSERT INTO spare_parts(part_code,part_name,category,quantity_in_stock,reorder_level,unit_price,supplier)
VALUES('BAT-001','12V Battery','Electrical',4,5,28500,'Power Auto');

COMMIT;
