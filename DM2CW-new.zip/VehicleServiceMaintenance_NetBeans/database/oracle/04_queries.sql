-- Useful SQL for demonstration / viva.

-- 1. Customer and vehicle details
SELECT c.customer_id, c.first_name || ' ' || c.last_name customer_name,
       v.registration_no, v.make, v.model
FROM customers c JOIN vehicles v ON v.customer_id=c.customer_id
ORDER BY c.customer_id;

-- 2. Upcoming bookings
SELECT b.booking_id, v.registration_no, b.booking_date, b.booking_time,
       b.service_type, b.status, b.estimated_cost
FROM service_bookings b JOIN vehicles v ON v.vehicle_id=b.vehicle_id
WHERE b.booking_date >= TRUNC(SYSDATE)
ORDER BY b.booking_date, b.booking_time;

-- 3. Low stock
SELECT part_code, part_name, quantity_in_stock, reorder_level
FROM spare_parts
WHERE quantity_in_stock < reorder_level;

-- 4. Vehicle spending using PL/SQL function
SELECT vehicle_id, registration_no, fn_vehicle_total_spend(vehicle_id) AS total_spend
FROM vehicles;

-- 5. Monthly revenue
SELECT TO_CHAR(i.invoice_date,'YYYY-MM') month,
       SUM(i.total_amount) revenue
FROM invoices i
WHERE i.payment_status='PAID'
GROUP BY TO_CHAR(i.invoice_date,'YYYY-MM')
ORDER BY month;
