-- PL/SQL procedures, function and cursor required by the assessment.

CREATE OR REPLACE PROCEDURE sp_add_customer(
    p_first_name IN VARCHAR2, p_last_name IN VARCHAR2, p_phone IN VARCHAR2,
    p_email IN VARCHAR2, p_address IN VARCHAR2
) AS
BEGIN
    INSERT INTO customers(first_name,last_name,phone,email,address)
    VALUES(p_first_name,p_last_name,p_phone,p_email,p_address);
END;
/

CREATE OR REPLACE PROCEDURE sp_add_vehicle(
    p_registration IN VARCHAR2, p_customer_id IN NUMBER, p_make IN VARCHAR2,
    p_model IN VARCHAR2, p_year IN NUMBER, p_mileage IN NUMBER, p_fuel IN VARCHAR2
) AS
BEGIN
    INSERT INTO vehicles(registration_no,customer_id,make,model,model_year,mileage,fuel_type)
    VALUES(UPPER(p_registration),p_customer_id,p_make,p_model,p_year,p_mileage,UPPER(p_fuel));
END;
/

CREATE OR REPLACE PROCEDURE sp_add_booking(
    p_vehicle_id IN NUMBER, p_date IN DATE, p_time IN VARCHAR2,
    p_service IN VARCHAR2, p_status IN VARCHAR2, p_cost IN NUMBER
) AS
BEGIN
    INSERT INTO service_bookings(vehicle_id,booking_date,booking_time,service_type,status,estimated_cost)
    VALUES(p_vehicle_id,p_date,p_time,p_service,UPPER(p_status),p_cost);
END;
/

CREATE OR REPLACE PROCEDURE sp_add_invoice(
    p_booking_id IN NUMBER, p_subtotal IN NUMBER, p_tax IN NUMBER,
    p_status IN VARCHAR2, p_method IN VARCHAR2
) AS
BEGIN
    INSERT INTO invoices(booking_id,subtotal,tax,payment_status,payment_method)
    VALUES(p_booking_id,p_subtotal,p_tax,UPPER(p_status),UPPER(p_method));
END;
/

CREATE OR REPLACE PROCEDURE sp_add_part(
    p_code IN VARCHAR2, p_name IN VARCHAR2, p_category IN VARCHAR2,
    p_qty IN NUMBER, p_reorder IN NUMBER, p_price IN NUMBER, p_supplier IN VARCHAR2
) AS
BEGIN
    INSERT INTO spare_parts(part_code,part_name,category,quantity_in_stock,reorder_level,unit_price,supplier)
    VALUES(UPPER(p_code),p_name,p_category,p_qty,p_reorder,p_price,p_supplier);
END;
/

CREATE OR REPLACE FUNCTION fn_vehicle_total_spend(p_vehicle_id NUMBER)
RETURN NUMBER
IS
    v_total NUMBER;
BEGIN
    SELECT NVL(SUM(i.total_amount),0)
    INTO v_total
    FROM invoices i
    JOIN service_bookings b ON b.booking_id=i.booking_id
    WHERE b.vehicle_id=p_vehicle_id;
    RETURN v_total;
END;
/

CREATE OR REPLACE PROCEDURE sp_vehicle_service_summary(
    p_vehicle_id IN NUMBER,
    p_total_services OUT NUMBER,
    p_total_spend OUT NUMBER
) AS
BEGIN
    SELECT COUNT(*) INTO p_total_services
    FROM service_bookings WHERE vehicle_id=p_vehicle_id;

    p_total_spend := fn_vehicle_total_spend(p_vehicle_id);
END;
/

-- Explicit cursor example for the viva/demo.
CREATE OR REPLACE PROCEDURE sp_print_low_stock
AS
    CURSOR c_parts IS
        SELECT part_code, part_name, quantity_in_stock, reorder_level
        FROM spare_parts
        WHERE quantity_in_stock < reorder_level
        ORDER BY quantity_in_stock;
BEGIN
    FOR r IN c_parts LOOP
        DBMS_OUTPUT.PUT_LINE(r.part_code || ' - ' || r.part_name ||
                             ' | Stock: ' || r.quantity_in_stock ||
                             ' | Reorder: ' || r.reorder_level);
    END LOOP;
END;
/

COMMIT;
