# NetBeans setup – exact steps

1. Extract the ZIP.
2. Open NetBeans.
3. File > Open Project.
4. Select `VehicleServiceMaintenance_NetBeans`.
5. Right-click the project > Clean and Build.
6. Right-click project > Run.
7. Login with `admin` / `admin123`.

If Maven shows dependency download errors:
- make sure the computer has internet on the first build;
- then Clean and Build again.

If Oracle connection fails:
1. Open `src/main/java/com/vehicle/service/DBConfig.java`.
2. Set the URL to the service that your Oracle installation exposes.
3. Set VSM_APP credentials.
4. Run the SQL scripts in the order in README.md.

If MongoDB connection fails:
1. Start MongoDB.
2. Run `mongosh`.
3. Execute `database/mongodb/01_collections.js`.
4. Test the connection from the login screen.

Do not put database passwords directly into screenshots or GitHub. For submission, environment variables are preferable.
