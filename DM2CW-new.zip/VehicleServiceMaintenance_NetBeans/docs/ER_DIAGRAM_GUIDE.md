# ER Diagram – Vehicle Service & Maintenance

Use these entities and relationships in draw.io / Lucidchart / Canva:

CUSTOMERS
- customer_id PK
- first_name
- last_name
- phone
- email
- address
- created_at

VEHICLES
- vehicle_id PK
- registration_no UK
- customer_id FK -> CUSTOMERS.customer_id
- make
- model
- model_year
- mileage
- fuel_type
- created_at

SERVICE_BOOKINGS
- booking_id PK
- vehicle_id FK -> VEHICLES.vehicle_id
- booking_date
- booking_time
- service_type
- status
- estimated_cost

INVOICES
- invoice_id PK
- booking_id FK -> SERVICE_BOOKINGS.booking_id
- invoice_date
- subtotal
- tax
- total_amount
- payment_status
- payment_method

SPARE_PARTS
- part_id PK
- part_code UK
- part_name
- category
- quantity_in_stock
- reorder_level
- unit_price
- supplier

Relationships:
CUSTOMERS 1 ---- N VEHICLES
VEHICLES 1 ---- N SERVICE_BOOKINGS
SERVICE_BOOKINGS 1 ---- 0..1 INVOICES
SPARE_PARTS is an independent inventory entity.

MongoDB is linked logically using Oracle vehicle_id / registration_no in:
vehicle_job_cards
technician_notes
service_history_logs
customer_complaints
diagnostic_summaries
