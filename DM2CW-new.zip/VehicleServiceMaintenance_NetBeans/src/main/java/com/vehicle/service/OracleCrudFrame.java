package com.vehicle.service;

import java.awt.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;

public class OracleCrudFrame extends JFrame {
    private final String type;
    private final JTable table = new JTable();
    private final DefaultTableModel model = new DefaultTableModel();
    private final JTextField search = new JTextField();

    private final Map<String, String> queries = new LinkedHashMap<>();
    private final Map<String, String[]> columns = new LinkedHashMap<>();

    public OracleCrudFrame(String type) {
        this.type = type;
        setTitle(type + " - Oracle Database");
        setSize(1050, 650);
        setLocationRelativeTo(null);

        setupDefinitions();

        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setBorder(new EmptyBorder(15, 15, 10, 15));
        top.add(AppTheme.title(type), BorderLayout.WEST);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.add(new JLabel("Search:"));
        search.setPreferredSize(new Dimension(220, 30));
        actions.add(search);
        JButton refresh = AppTheme.button("Refresh");
refresh.addActionListener(e -> load());

JButton add = AppTheme.button("Add");
add.addActionListener(e -> addRecord());

JButton update = AppTheme.button("Update Selected");
update.addActionListener(e -> updateRecord());

JButton delete = new JButton("Delete Selected");
delete.addActionListener(e -> deleteRecord());

actions.add(refresh);
actions.add(add);
actions.add(update);
actions.add(delete);
        top.add(actions, BorderLayout.SOUTH);

        table.setModel(model);
        table.setAutoCreateRowSorter(true);
        table.setForeground(AppTheme.TEXT);
        table.setBackground(Color.WHITE);
        table.setGridColor(AppTheme.BORDER);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(AppTheme.TEXT);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        search.addActionListener(e -> load());
        load();
    }

    private void setupDefinitions() {

    // =====================================================
    // CUSTOMERS
    // =====================================================
    queries.put(
        "Customers",
        "SELECT customer_id, first_name, last_name, phone, email, address, created_at "
        + "FROM customers "
        + "WHERE LOWER(first_name) LIKE LOWER(?) "
        + "OR LOWER(last_name) LIKE LOWER(?) "
        + "OR LOWER(phone) LIKE LOWER(?) "
        + "OR LOWER(email) LIKE LOWER(?) "
        + "OR LOWER(address) LIKE LOWER(?) "
        + "ORDER BY customer_id"
    );

    columns.put(
        "Customers",
        new String[]{
            "ID",
            "First Name",
            "Last Name",
            "Phone",
            "Email",
            "Address",
            "Created"
        }
    );


    // =====================================================
    // VEHICLES
    // =====================================================
    queries.put(
        "Vehicles",
        "SELECT vehicle_id, registration_no, customer_id, make, model, "
        + "model_year, mileage, fuel_type "
        + "FROM vehicles "
        + "WHERE LOWER(registration_no) LIKE LOWER(?) "
        + "OR TO_CHAR(customer_id) LIKE ? "
        + "OR LOWER(make) LIKE LOWER(?) "
        + "OR LOWER(model) LIKE LOWER(?) "
        + "OR TO_CHAR(model_year) LIKE ? "
        + "OR TO_CHAR(mileage) LIKE ? "
        + "OR LOWER(fuel_type) LIKE LOWER(?) "
        + "ORDER BY vehicle_id"
    );

    columns.put(
        "Vehicles",
        new String[]{
            "ID",
            "Registration",
            "Customer ID",
            "Make",
            "Model",
            "Year",
            "Mileage",
            "Fuel"
        }
    );


    // =====================================================
    // BOOKINGS
    // =====================================================
    queries.put(
    "Bookings",
    "SELECT booking_id, vehicle_id, booking_date, booking_time, "
    + "service_type, status, estimated_cost "
    + "FROM service_bookings "
    + "WHERE TO_CHAR(booking_id) LIKE ? "
    + "OR TO_CHAR(vehicle_id) LIKE ? "
    + "OR TO_CHAR(booking_date, 'YYYY-MM-DD') LIKE ? "
    + "OR booking_time LIKE ? "
    + "OR LOWER(service_type) LIKE LOWER(?) "
    + "OR LOWER(status) LIKE LOWER(?) "
    + "OR TO_CHAR(estimated_cost) LIKE ? "
    + "ORDER BY booking_id"
);

    columns.put(
        "Bookings",
        new String[]{
            "ID",
            "Vehicle ID",
            "Date",
            "Time",
            "Service",
            "Status",
            "Estimated Cost"
        }
    );


    // =====================================================
    // INVOICES
    // =====================================================
   queries.put(
    "Invoices",
    "SELECT invoice_id, booking_id, invoice_date, subtotal, tax, "
    + "total_amount, payment_status, payment_method "
    + "FROM invoices "
    + "WHERE TO_CHAR(invoice_id) LIKE ? "
    + "OR TO_CHAR(booking_id) LIKE ? "
    + "OR TO_CHAR(invoice_date, 'YYYY-MM-DD') LIKE ? "
    + "OR TO_CHAR(subtotal) LIKE ? "
    + "OR TO_CHAR(tax) LIKE ? "
    + "OR TO_CHAR(total_amount) LIKE ? "
    + "OR LOWER(payment_status) LIKE LOWER(?) "
    + "OR LOWER(payment_method) LIKE LOWER(?) "
    + "ORDER BY invoice_id"
);

    columns.put(
        "Invoices",
        new String[]{
            "ID",
            "Booking ID",
            "Date",
            "Subtotal",
            "Tax",
            "Total",
            "Payment Status",
            "Method"
        }
    );


    // =====================================================
    // SPARE PARTS
    // =====================================================
    queries.put(
    "Spare Parts",
    "SELECT part_id, part_code, part_name, category, "
    + "quantity_in_stock, reorder_level, unit_price, supplier "
    + "FROM spare_parts "
    + "WHERE TO_CHAR(part_id) LIKE ? "
    + "OR LOWER(part_code) LIKE LOWER(?) "
    + "OR LOWER(part_name) LIKE LOWER(?) "
    + "OR LOWER(category) LIKE LOWER(?) "
    + "OR TO_CHAR(quantity_in_stock) LIKE ? "
    + "OR TO_CHAR(reorder_level) LIKE ? "
    + "OR TO_CHAR(unit_price) LIKE ? "
    + "OR LOWER(supplier) LIKE LOWER(?) "
    + "ORDER BY part_id"
);

    columns.put(
        "Spare Parts",
        new String[]{
            "ID",
            "Code",
            "Part",
            "Category",
            "Stock",
            "Reorder",
            "Unit Price",
            "Supplier"
        }
    );
}
private void load() {

    String sql = queries.get(type);

    if (sql == null) {
        return;
    }

    model.setRowCount(0);
    model.setColumnIdentifiers(columns.get(type));

    try (
        Connection c = OracleConnection.getConnection();
        PreparedStatement ps = c.prepareStatement(sql)
    ) {

        String keyword = search.getText().trim();
        String value = "%" + keyword + "%";


        // =====================================================
        // CUSTOMERS
        // 5 placeholders
        // =====================================================

        if ("Customers".equals(type)) {

            ps.setString(1, value);
            ps.setString(2, value);
            ps.setString(3, value);
            ps.setString(4, value);
            ps.setString(5, value);
        }


        // =====================================================
        // VEHICLES
        // 7 placeholders
        // =====================================================

        else if ("Vehicles".equals(type)) {

            ps.setString(1, value);
            ps.setString(2, value);
            ps.setString(3, value);
            ps.setString(4, value);
            ps.setString(5, value);
            ps.setString(6, value);
            ps.setString(7, value);
        }


        // =====================================================
// BOOKINGS
// 7 placeholders
// =====================================================

else if ("Bookings".equals(type)) {

    ps.setString(1, value);
    ps.setString(2, value);
    ps.setString(3, value);
    ps.setString(4, value);
    ps.setString(5, value);
    ps.setString(6, value);
    ps.setString(7, value);
}


       // =====================================================
// INVOICES
// 8 placeholders
// =====================================================

else if ("Invoices".equals(type)) {

    ps.setString(1, value);
    ps.setString(2, value);
    ps.setString(3, value);
    ps.setString(4, value);
    ps.setString(5, value);
    ps.setString(6, value);
    ps.setString(7, value);
    ps.setString(8, value);
}

       // =====================================================
// SPARE PARTS
// 8 placeholders
// =====================================================

else if ("Spare Parts".equals(type)) {

    ps.setString(1, value);
    ps.setString(2, value);
    ps.setString(3, value);
    ps.setString(4, value);
    ps.setString(5, value);
    ps.setString(6, value);
    ps.setString(7, value);
    ps.setString(8, value);
}

        try (ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                int columnCount =
                    rs.getMetaData().getColumnCount();

                Object[] row = new Object[columnCount];

                for (int i = 0; i < columnCount; i++) {
                    row[i] = rs.getObject(i + 1);
                }

                model.addRow(row);
            }
        }

    } catch (SQLException ex) {

        JOptionPane.showMessageDialog(
            this,
            "Unable to load data:\n" + ex.getMessage(),
            "Oracle",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
    private void addRecord() {
        switch (type) {
            case "Customers" -> customerDialog();
            case "Vehicles" -> vehicleDialog();
            case "Bookings" -> bookingDialog();
            case "Invoices" -> invoiceDialog();
            case "Spare Parts" -> partDialog();
        }
    }

    private void customerDialog() {
        JTextField first = new JTextField(), last = new JTextField(), phone = new JTextField(), email = new JTextField(), address = new JTextField();
        JPanel p = fields(new String[]{"First Name","Last Name","Phone","Email","Address"}, first,last,phone,email,address);
        if (JOptionPane.showConfirmDialog(this,p,"Add Customer",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION) {
            try (Connection c=OracleConnection.getConnection();
                 CallableStatement cs=c.prepareCall("{call sp_add_customer(?,?,?,?,?)}")) {
                cs.setString(1,first.getText()); cs.setString(2,last.getText()); cs.setString(3,phone.getText());
                cs.setString(4,email.getText()); cs.setString(5,address.getText()); cs.execute();
                load();
            } catch(SQLException ex){ error(ex); }
        }
        
    }
    

   private void vehicleDialog() {

    JTextField reg = new JTextField();
    JTextField customer = new JTextField();
    JTextField make = new JTextField();
    JTextField modelF = new JTextField();
    JTextField year = new JTextField();
    JTextField mileage = new JTextField();
    JTextField fuel = new JTextField("PETROL");

    JPanel p = fields(
        new String[]{
            "Registration No",
            "Customer ID",
            "Make",
            "Model",
            "Model Year",
            "Mileage",
            "Fuel Type"
        },
        reg,
        customer,
        make,
        modelF,
        year,
        mileage,
        fuel
    );

    if (JOptionPane.showConfirmDialog(
            this,
            p,
            "Add Vehicle",
            JOptionPane.OK_CANCEL_OPTION
        ) != JOptionPane.OK_OPTION) {

        return;
    }

    // Check empty fields
    if (reg.getText().trim().isEmpty()
            || customer.getText().trim().isEmpty()
            || make.getText().trim().isEmpty()
            || modelF.getText().trim().isEmpty()
            || year.getText().trim().isEmpty()
            || mileage.getText().trim().isEmpty()
            || fuel.getText().trim().isEmpty()) {

        JOptionPane.showMessageDialog(
            this,
            "Please fill in all fields.",
            "Validation",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    try {

        int customerId = Integer.parseInt(
            customer.getText().trim()
        );

        int modelYear = Integer.parseInt(
            year.getText().trim()
        );

        int mileageValue = Integer.parseInt(
            mileage.getText().trim()
        );

        try (
            Connection c = OracleConnection.getConnection();
            CallableStatement cs =
                c.prepareCall("{call sp_add_vehicle(?,?,?,?,?,?,?)}")
        ) {

            cs.setString(1, reg.getText().trim());
            cs.setInt(2, customerId);
            cs.setString(3, make.getText().trim());
            cs.setString(4, modelF.getText().trim());
            cs.setInt(5, modelYear);
            cs.setInt(6, mileageValue);
            cs.setString(7, fuel.getText().trim());

            cs.execute();

            JOptionPane.showMessageDialog(
                this,
                "Vehicle added successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
            );

            load();
        }

    } catch (NumberFormatException ex) {

        JOptionPane.showMessageDialog(
            this,
            "Customer ID, Model Year and Mileage must be numbers.",
            "Invalid Input",
            JOptionPane.WARNING_MESSAGE
        );

    } catch (SQLException ex) {

        error(ex);
    }
}

   private void bookingDialog() {

    JTextField vehicle = new JTextField();
    JTextField date = new JTextField("2026-08-20");
    JTextField time = new JTextField("09:00");
    JTextField service = new JTextField("GENERAL SERVICE");
    JTextField cost = new JTextField("0");

    JComboBox<String> status = new JComboBox<>(
        new String[]{
            "BOOKED",
            "CONFIRMED",
            "IN_PROGRESS",
            "COMPLETED",
            "CANCELLED"
        }
    );

    JPanel p = fields(
        new String[]{
            "Vehicle ID",
            "Date (YYYY-MM-DD)",
            "Time (HH:MM)",
            "Service Type",
            "Status",
            "Estimated Cost"
        },
        vehicle,
        date,
        time,
        service,
        status,
        cost
    );

    int result = JOptionPane.showConfirmDialog(
        this,
        p,
        "Add Booking",
        JOptionPane.OK_CANCEL_OPTION,
        JOptionPane.PLAIN_MESSAGE
    );

    // User pressed Cancel
    if (result != JOptionPane.OK_OPTION) {
        return;
    }

    try {

        // -----------------------------
        // Validate input
        // -----------------------------

        int vehicleId = Integer.parseInt(vehicle.getText().trim());

        java.sql.Date bookingDate = java.sql.Date.valueOf(
    date.getText().trim()
);

        String bookingTime = time.getText().trim();

        String serviceType = service.getText().trim();

        String bookingStatus =
            status.getSelectedItem().toString();

        java.math.BigDecimal estimatedCost =
            new java.math.BigDecimal(
                cost.getText().trim()
            );


        // -----------------------------
        // Call Oracle procedure
        // -----------------------------

        try (
            Connection c = OracleConnection.getConnection();
            CallableStatement cs =
                c.prepareCall(
                    "{call sp_add_booking(?,?,?,?,?,?)}"
                )
        ) {

            cs.setInt(1, vehicleId);
            cs.setDate(2, bookingDate);
            cs.setString(3, bookingTime);
            cs.setString(4, serviceType);
            cs.setString(5, bookingStatus);
            cs.setBigDecimal(6, estimatedCost);

            cs.execute();

        }


        // -----------------------------
        // SUCCESS MESSAGE
        // -----------------------------

        JOptionPane.showMessageDialog(
            this,
            "Booking added successfully!",
            "Success",
            JOptionPane.INFORMATION_MESSAGE
        );


        // -----------------------------
        // REFRESH TABLE
        // -----------------------------

        load();

    } catch (NumberFormatException ex) {

        JOptionPane.showMessageDialog(
            this,
            "Vehicle ID and Estimated Cost must contain valid numbers.",
            "Invalid Input",
            JOptionPane.ERROR_MESSAGE
        );

    } catch (IllegalArgumentException ex) {

        JOptionPane.showMessageDialog(
            this,
            "Invalid date.\nPlease use YYYY-MM-DD.",
            "Invalid Date",
            JOptionPane.ERROR_MESSAGE
        );

    } catch (SQLException ex) {

        JOptionPane.showMessageDialog(
            this,
            "Database Error:\n" + ex.getMessage(),
            "Oracle",
            JOptionPane.ERROR_MESSAGE
        );

    } catch (Exception ex) {

        JOptionPane.showMessageDialog(
            this,
            "Unexpected Error:\n" + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}

    private void invoiceDialog() {

    JTextField booking = new JTextField();
    JTextField subtotal = new JTextField();
    JTextField tax = new JTextField("0");

    JComboBox<String> status = new JComboBox<>(
        new String[]{"PAID", "PENDING", "PARTIAL"}
    );

    JComboBox<String> method = new JComboBox<>(
        new String[]{"CASH", "CARD", "ONLINE", "BANK TRANSFER"}
    );

    JPanel p = fields(
        new String[]{
            "Booking ID",
            "Subtotal",
            "Tax",
            "Payment Status",
            "Payment Method"
        },
        booking,
        subtotal,
        tax,
        status,
        method
    );

    if (
        JOptionPane.showConfirmDialog(
            this,
            p,
            "Add Invoice",
            JOptionPane.OK_CANCEL_OPTION
        ) != JOptionPane.OK_OPTION
    ) {
        return;
    }

    try {

        int bookingId =
            Integer.parseInt(booking.getText().trim());

        java.math.BigDecimal subtotalValue =
            new java.math.BigDecimal(
                subtotal.getText().trim()
            );

        java.math.BigDecimal taxValue =
            new java.math.BigDecimal(
                tax.getText().trim()
            );

        try (
            Connection c = OracleConnection.getConnection();
            CallableStatement cs =
                c.prepareCall(
                    "{call sp_add_invoice(?,?,?,?,?)}"
                )
        ) {

            cs.setInt(1, bookingId);
            cs.setBigDecimal(2, subtotalValue);
            cs.setBigDecimal(3, taxValue);
            cs.setString(
                4,
                status.getSelectedItem().toString()
            );
            cs.setString(
                5,
                method.getSelectedItem().toString()
            );

            cs.execute();
        }

        JOptionPane.showMessageDialog(
            this,
            "Invoice added successfully!",
            "Success",
            JOptionPane.INFORMATION_MESSAGE
        );

        load();

    } catch (NumberFormatException ex) {

        JOptionPane.showMessageDialog(
            this,
            "Booking ID, Subtotal and Tax must contain valid numbers.",
            "Invalid Input",
            JOptionPane.ERROR_MESSAGE
        );

    } catch (SQLException ex) {

        error(ex);

    } catch (Exception ex) {

        JOptionPane.showMessageDialog(
            this,
            "Unexpected Error:\n" + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}

    private void partDialog() {

    JTextField code = new JTextField();
    JTextField name = new JTextField();
    JTextField category = new JTextField();
    JTextField quantity = new JTextField("0");
    JTextField reorder = new JTextField("5");
    JTextField price = new JTextField("0");
    JTextField supplier = new JTextField();

    JPanel p = fields(
        new String[]{
            "Part Code",
            "Part Name",
            "Category",
            "Quantity in Stock",
            "Reorder Level",
            "Unit Price",
            "Supplier"
        },
        code,
        name,
        category,
        quantity,
        reorder,
        price,
        supplier
    );

    if (JOptionPane.showConfirmDialog(
            this,
            p,
            "Add Spare Part",
            JOptionPane.OK_CANCEL_OPTION
        ) != JOptionPane.OK_OPTION) {
        return;
    }

    try {

        int quantityValue =
            Integer.parseInt(quantity.getText().trim());

        int reorderValue =
            Integer.parseInt(reorder.getText().trim());

        java.math.BigDecimal priceValue =
            new java.math.BigDecimal(price.getText().trim());

        try (
            Connection c = OracleConnection.getConnection();
            CallableStatement cs =
                c.prepareCall("{call sp_add_spare_part(?,?,?,?,?,?,?)}")
        ) {

            cs.setString(1, code.getText().trim());
            cs.setString(2, name.getText().trim());
            cs.setString(3, category.getText().trim());
            cs.setInt(4, quantityValue);
            cs.setInt(5, reorderValue);
            cs.setBigDecimal(6, priceValue);
            cs.setString(7, supplier.getText().trim());

            cs.execute();
        }

        JOptionPane.showMessageDialog(
            this,
            "Spare part added successfully!",
            "Success",
            JOptionPane.INFORMATION_MESSAGE
        );

        load();

    } catch (NumberFormatException ex) {

        JOptionPane.showMessageDialog(
            this,
            "Quantity, Reorder Level and Unit Price must contain valid numbers.",
            "Invalid Input",
            JOptionPane.ERROR_MESSAGE
        );

    } catch (SQLException ex) {

        error(ex);

    } catch (Exception ex) {

        JOptionPane.showMessageDialog(
            this,
            "Unexpected Error:\n" + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}

    private JPanel fields(String[] labels, JComponent... comps) {
        JPanel p=new JPanel(new GridLayout(labels.length,2,8,8));
        for(int i=0;i<labels.length;i++){ p.add(new JLabel(labels[i])); p.add(comps[i]); }
        p.setBorder(new EmptyBorder(10,10,10,10)); return p;
    }

    private void updateRecord() {

    int row = table.getSelectedRow();

    if (row < 0) {
        JOptionPane.showMessageDialog(
                this,
                "Please select a record first.",
                "No Selection",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    int id = ((Number) table.getValueAt(row, 0)).intValue();

    switch (type) {

        case "Customers" -> updateCustomer(row, id);

        case "Vehicles" -> updateVehicle(row, id);

        case "Bookings" -> updateBooking(row, id);

        case "Invoices" -> updateInvoice(row, id);

        case "Spare Parts" -> updateSparePart(row, id);
    }
}


/* =========================================================
   UPDATE CUSTOMER
   ========================================================= */

private void updateCustomer(int row, int id) {

    JTextField first = new JTextField(
            String.valueOf(table.getValueAt(row, 1))
    );

    JTextField last = new JTextField(
            String.valueOf(table.getValueAt(row, 2))
    );

    JTextField phone = new JTextField(
            String.valueOf(table.getValueAt(row, 3))
    );

    JTextField email = new JTextField(
            String.valueOf(table.getValueAt(row, 4))
    );

    JTextField address = new JTextField(
            String.valueOf(table.getValueAt(row, 5))
    );

    JPanel p = fields(
            new String[]{
                "First Name",
                "Last Name",
                "Phone",
                "Email",
                "Address"
            },
            first,
            last,
            phone,
            email,
            address
    );

    int result = JOptionPane.showConfirmDialog(
            this,
            p,
            "Update Customer",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
    );

    if (result != JOptionPane.OK_OPTION) {
        return;
    }

    try (
            Connection c = OracleConnection.getConnection();
            PreparedStatement ps = c.prepareStatement(
                    "UPDATE customers SET "
                    + "first_name=?, "
                    + "last_name=?, "
                    + "phone=?, "
                    + "email=?, "
                    + "address=? "
                    + "WHERE customer_id=?"
            )
    ) {

        ps.setString(1, first.getText().trim());
        ps.setString(2, last.getText().trim());
        ps.setString(3, phone.getText().trim());
        ps.setString(4, email.getText().trim());
        ps.setString(5, address.getText().trim());
        ps.setInt(6, id);

        ps.executeUpdate();

        JOptionPane.showMessageDialog(
                this,
                "Customer updated successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
        );

        load();

    } catch (SQLException ex) {
        error(ex);
    }
}


/* =========================================================
   UPDATE VEHICLE
   ========================================================= */

private void updateVehicle(int row, int id) {

    JTextField registration = new JTextField(
            String.valueOf(table.getValueAt(row, 1))
    );

    JTextField customerId = new JTextField(
            String.valueOf(table.getValueAt(row, 2))
    );

    JTextField make = new JTextField(
            String.valueOf(table.getValueAt(row, 3))
    );

    JTextField modelField = new JTextField(
            String.valueOf(table.getValueAt(row, 4))
    );

    JTextField year = new JTextField(
            String.valueOf(table.getValueAt(row, 5))
    );

    JTextField mileage = new JTextField(
            String.valueOf(table.getValueAt(row, 6))
    );

    JTextField fuel = new JTextField(
            String.valueOf(table.getValueAt(row, 7))
    );

    JPanel p = fields(
            new String[]{
                "Registration No",
                "Customer ID",
                "Make",
                "Model",
                "Model Year",
                "Mileage",
                "Fuel Type"
            },
            registration,
            customerId,
            make,
            modelField,
            year,
            mileage,
            fuel
    );

    int result = JOptionPane.showConfirmDialog(
            this,
            p,
            "Update Vehicle",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
    );

    if (result != JOptionPane.OK_OPTION) {
        return;
    }

    try {

        int customerIdValue =
                Integer.parseInt(customerId.getText().trim());

        int yearValue =
                Integer.parseInt(year.getText().trim());

        int mileageValue =
                Integer.parseInt(mileage.getText().trim());

        try (
                Connection c = OracleConnection.getConnection();
                PreparedStatement ps = c.prepareStatement(
                        "UPDATE vehicles SET "
                        + "registration_no=?, "
                        + "customer_id=?, "
                        + "make=?, "
                        + "model=?, "
                        + "model_year=?, "
                        + "mileage=?, "
                        + "fuel_type=? "
                        + "WHERE vehicle_id=?"
                )
        ) {

            ps.setString(1, registration.getText().trim());
            ps.setInt(2, customerIdValue);
            ps.setString(3, make.getText().trim());
            ps.setString(4, modelField.getText().trim());
            ps.setInt(5, yearValue);
            ps.setInt(6, mileageValue);
            ps.setString(7, fuel.getText().trim());
            ps.setInt(8, id);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Vehicle updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            load();
        }

    } catch (NumberFormatException ex) {

        JOptionPane.showMessageDialog(
                this,
                "Customer ID, Model Year and Mileage must be valid numbers.",
                "Invalid Input",
                JOptionPane.WARNING_MESSAGE
        );

    } catch (SQLException ex) {
        error(ex);
    }
}


/* =========================================================
   UPDATE BOOKING
   ========================================================= */

private void updateBooking(int row, int id) {

    JTextField vehicle = new JTextField(
            String.valueOf(table.getValueAt(row, 1))
    );

    JTextField date = new JTextField(
            String.valueOf(table.getValueAt(row, 2))
    );

    JTextField time = new JTextField(
            String.valueOf(table.getValueAt(row, 3))
    );

    JTextField service = new JTextField(
            String.valueOf(table.getValueAt(row, 4))
    );

    JComboBox<String> status = new JComboBox<>(
            new String[]{
                "BOOKED",
                "CONFIRMED",
                "IN_PROGRESS",
                "COMPLETED",
                "CANCELLED"
            }
    );

    status.setSelectedItem(
            String.valueOf(table.getValueAt(row, 5))
    );

    JTextField cost = new JTextField(
            String.valueOf(table.getValueAt(row, 6))
    );

    JPanel p = fields(
            new String[]{
                "Vehicle ID",
                "Date (YYYY-MM-DD)",
                "Time (HH:MM)",
                "Service Type",
                "Status",
                "Estimated Cost"
            },
            vehicle,
            date,
            time,
            service,
            status,
            cost
    );

    int result = JOptionPane.showConfirmDialog(
            this,
            p,
            "Update Booking",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
    );

    if (result != JOptionPane.OK_OPTION) {
        return;
    }

    try {

        int vehicleId =
                Integer.parseInt(vehicle.getText().trim());

        java.sql.Date bookingDate =
                java.sql.Date.valueOf(date.getText().trim());

        java.math.BigDecimal estimatedCost =
                new java.math.BigDecimal(
                        cost.getText().trim()
                );

        try (
                Connection c = OracleConnection.getConnection();
                PreparedStatement ps = c.prepareStatement(
                        "UPDATE service_bookings SET "
                        + "vehicle_id=?, "
                        + "booking_date=?, "
                        + "booking_time=?, "
                        + "service_type=?, "
                        + "status=?, "
                        + "estimated_cost=? "
                        + "WHERE booking_id=?"
                )
        ) {

            ps.setInt(1, vehicleId);
            ps.setDate(2, bookingDate);
            ps.setString(3, time.getText().trim());
            ps.setString(4, service.getText().trim());
            ps.setString(
                    5,
                    status.getSelectedItem().toString()
            );
            ps.setBigDecimal(6, estimatedCost);
            ps.setInt(7, id);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Booking updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            load();
        }

    } catch (NumberFormatException ex) {

        JOptionPane.showMessageDialog(
                this,
                "Vehicle ID and Estimated Cost must be valid numbers.",
                "Invalid Input",
                JOptionPane.WARNING_MESSAGE
        );

    } catch (IllegalArgumentException ex) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid date. Please use YYYY-MM-DD.",
                "Invalid Date",
                JOptionPane.WARNING_MESSAGE
        );

    } catch (SQLException ex) {
        error(ex);
    }
}


/* =========================================================
   UPDATE INVOICE
   ========================================================= */

private void updateInvoice(int row, int id) {

    JTextField booking = new JTextField(
            String.valueOf(table.getValueAt(row, 1))
    );

    JTextField date = new JTextField(
            String.valueOf(table.getValueAt(row, 2))
    );

    JTextField subtotal = new JTextField(
            String.valueOf(table.getValueAt(row, 3))
    );

    JTextField tax = new JTextField(
            String.valueOf(table.getValueAt(row, 4))
    );

    JTextField total = new JTextField(
            String.valueOf(table.getValueAt(row, 5))
    );

    JComboBox<String> status = new JComboBox<>(
            new String[]{
                "PAID",
                "PENDING",
                "PARTIAL"
            }
    );

    status.setSelectedItem(
            String.valueOf(table.getValueAt(row, 6))
    );

    JComboBox<String> method = new JComboBox<>(
            new String[]{
                "CASH",
                "CARD",
                "ONLINE",
                "BANK TRANSFER"
            }
    );

    method.setSelectedItem(
            String.valueOf(table.getValueAt(row, 7))
    );

    JPanel p = fields(
            new String[]{
                "Booking ID",
                "Invoice Date",
                "Subtotal",
                "Tax",
                "Total Amount",
                "Payment Status",
                "Payment Method"
            },
            booking,
            date,
            subtotal,
            tax,
            total,
            status,
            method
    );

    int result = JOptionPane.showConfirmDialog(
            this,
            p,
            "Update Invoice",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
    );

    if (result != JOptionPane.OK_OPTION) {
        return;
    }

    try {

        int bookingId =
                Integer.parseInt(booking.getText().trim());

        java.sql.Date invoiceDate =
                java.sql.Date.valueOf(date.getText().trim());

        java.math.BigDecimal subtotalValue =
                new java.math.BigDecimal(
                        subtotal.getText().trim()
                );

        java.math.BigDecimal taxValue =
                new java.math.BigDecimal(
                        tax.getText().trim()
                );

        java.math.BigDecimal totalValue =
                new java.math.BigDecimal(
                        total.getText().trim()
                );

        try (
                Connection c = OracleConnection.getConnection();
                PreparedStatement ps = c.prepareStatement(
                        "UPDATE invoices SET "
                        + "booking_id=?, "
                        + "invoice_date=?, "
                        + "subtotal=?, "
                        + "tax=?, "
                        + "total_amount=?, "
                        + "payment_status=?, "
                        + "payment_method=? "
                        + "WHERE invoice_id=?"
                )
        ) {

            ps.setInt(1, bookingId);
            ps.setDate(2, invoiceDate);
            ps.setBigDecimal(3, subtotalValue);
            ps.setBigDecimal(4, taxValue);
            ps.setBigDecimal(5, totalValue);
            ps.setString(
                    6,
                    status.getSelectedItem().toString()
            );
            ps.setString(
                    7,
                    method.getSelectedItem().toString()
            );
            ps.setInt(8, id);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Invoice updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            load();
        }

    } catch (NumberFormatException ex) {

        JOptionPane.showMessageDialog(
                this,
                "Booking ID and amounts must be valid numbers.",
                "Invalid Input",
                JOptionPane.WARNING_MESSAGE
        );

    } catch (IllegalArgumentException ex) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid date. Please use YYYY-MM-DD.",
                "Invalid Date",
                JOptionPane.WARNING_MESSAGE
        );

    } catch (SQLException ex) {
        error(ex);
    }
}


/* =========================================================
   UPDATE SPARE PART
   ========================================================= */

private void updateSparePart(int row, int id) {

    JTextField code = new JTextField(
            String.valueOf(table.getValueAt(row, 1))
    );

    JTextField name = new JTextField(
            String.valueOf(table.getValueAt(row, 2))
    );

    JTextField category = new JTextField(
            String.valueOf(table.getValueAt(row, 3))
    );

    JTextField quantity = new JTextField(
            String.valueOf(table.getValueAt(row, 4))
    );

    JTextField reorder = new JTextField(
            String.valueOf(table.getValueAt(row, 5))
    );

    JTextField price = new JTextField(
            String.valueOf(table.getValueAt(row, 6))
    );

    JTextField supplier = new JTextField(
            String.valueOf(table.getValueAt(row, 7))
    );

    JPanel p = fields(
            new String[]{
                "Part Code",
                "Part Name",
                "Category",
                "Quantity in Stock",
                "Reorder Level",
                "Unit Price",
                "Supplier"
            },
            code,
            name,
            category,
            quantity,
            reorder,
            price,
            supplier
    );

    int result = JOptionPane.showConfirmDialog(
            this,
            p,
            "Update Spare Part",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
    );

    if (result != JOptionPane.OK_OPTION) {
        return;
    }

    try {

        int quantityValue =
                Integer.parseInt(quantity.getText().trim());

        int reorderValue =
                Integer.parseInt(reorder.getText().trim());

        java.math.BigDecimal priceValue =
                new java.math.BigDecimal(
                        price.getText().trim()
                );

        try (
                Connection c = OracleConnection.getConnection();
                PreparedStatement ps = c.prepareStatement(
                        "UPDATE spare_parts SET "
                        + "part_code=?, "
                        + "part_name=?, "
                        + "category=?, "
                        + "quantity_in_stock=?, "
                        + "reorder_level=?, "
                        + "unit_price=?, "
                        + "supplier=? "
                        + "WHERE part_id=?"
                )
        ) {

            ps.setString(1, code.getText().trim());
            ps.setString(2, name.getText().trim());
            ps.setString(3, category.getText().trim());
            ps.setInt(4, quantityValue);
            ps.setInt(5, reorderValue);
            ps.setBigDecimal(6, priceValue);
            ps.setString(7, supplier.getText().trim());
            ps.setInt(8, id);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Spare part updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            load();
        }

    } catch (NumberFormatException ex) {

        JOptionPane.showMessageDialog(
                this,
                "Quantity, Reorder Level and Unit Price must be valid numbers.",
                "Invalid Input",
                JOptionPane.WARNING_MESSAGE
        );

    } catch (SQLException ex) {
        error(ex);
    }
}


/* =========================================================
   DELETE
   ========================================================= */

private void deleteRecord() {

    int row = table.getSelectedRow();

    if (row < 0) {
        JOptionPane.showMessageDialog(
                this,
                "Select a row first."
        );
        return;
    }

    int id =
            ((Number) table.getValueAt(row, 0)).intValue();

    String tableName = switch (type) {
        case "Customers" -> "customers";
        case "Vehicles" -> "vehicles";
        case "Bookings" -> "service_bookings";
        case "Invoices" -> "invoices";
        default -> "spare_parts";
    };

    String idCol = switch (type) {
        case "Customers" -> "customer_id";
        case "Vehicles" -> "vehicle_id";
        case "Bookings" -> "booking_id";
        case "Invoices" -> "invoice_id";
        default -> "part_id";
    };

    if (JOptionPane.showConfirmDialog(
            this,
            "Delete ID " + id + "?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    ) != JOptionPane.YES_OPTION) {

        return;
    }

    try (
            Connection c = OracleConnection.getConnection();
            PreparedStatement ps = c.prepareStatement(
                    "DELETE FROM " + tableName
                    + " WHERE " + idCol + "=?"
            )
    ) {

        ps.setInt(1, id);

        ps.executeUpdate();

        load();

    } catch (SQLException ex) {
        error(ex);
    }
}


/* =========================================================
   ERROR MESSAGE
   ========================================================= */

private void error(Exception ex) {

    JOptionPane.showMessageDialog(
            this,
            ex.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
    );
}
}