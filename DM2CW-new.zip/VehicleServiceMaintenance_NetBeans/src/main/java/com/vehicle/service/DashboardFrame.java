package com.vehicle.service;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class DashboardFrame extends JFrame {

    private final JPanel content =
            new JPanel(new BorderLayout());

    private final JLabel status =
            new JLabel(" Ready");


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public DashboardFrame() {

        setTitle(
                "Vehicle Service & Maintenance Management System"
        );

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setSize(
                1250,
                760
        );

        setLocationRelativeTo(null);


        // =====================================================
        // LEFT NAVIGATION
        // =====================================================

        JPanel nav = new JPanel();

        nav.setLayout(
                new BoxLayout(
                        nav,
                        BoxLayout.Y_AXIS
                )
        );

        // Light sidebar
        nav.setBackground(
                new Color(
                        248,
                        250,
                        252
                )
        );

        nav.setBorder(
                new EmptyBorder(
                        20,
                        12,
                        20,
                        12
                )
        );

        nav.setPreferredSize(
                new Dimension(
                        220,
                        0
                )
        );


        // =====================================================
        // NAVIGATION BUTTONS
        // =====================================================

        addNav(
                nav,
                "Dashboard",
                () -> showDashboard()
        );


        addNav(
                nav,
                "Customers",
                () -> openCrud("Customers")
        );


        addNav(
                nav,
                "Vehicles",
                () -> openCrud("Vehicles")
        );


        addNav(
                nav,
                "Service Bookings",
                () -> openCrud("Bookings")
        );


        addNav(
                nav,
                "Invoices & Payments",
                () -> openCrud("Invoices")
        );


        addNav(
                nav,
                "Spare Parts",
                () -> openCrud("Spare Parts")
        );


        addNav(
                nav,
                "MongoDB Job Cards",
                () -> new MongoCollectionFrame(
                        "Vehicle Job Cards",
                        "service_records"
                ).setVisible(true)
        );


        addNav(
                nav,
                "Technician Notes",
                () -> new TechnicianNotesFrame()
                        .setVisible(true)
        );


        addNav(
                nav,
                "Service History",
                () -> new MongoCollectionFrame(
                        "Service History Logs",
                        "service_records"
                ).setVisible(true)
        );


        addNav(
                nav,
                "Complaints & Feedback",
                () -> new CustomerComplaintsFrame()
                        .setVisible(true)
        );


        addNav(
                nav,
                "Diagnostics",
                () -> new DiagnosticSummariesFrame()
                        .setVisible(true)
        );


        addNav(
                nav,
                "Connection Test",
                () -> connectionDialog()
        );


        nav.add(
                Box.createVerticalGlue()
        );


        // =====================================================
        // MAIN CONTENT
        // =====================================================

        content.setBackground(
                new Color(
                        245,
                        247,
                        252
                )
        );


        showDashboard();


        // =====================================================
        // TOP BAR
        // =====================================================

        JPanel top =
                new JPanel(
                        new BorderLayout()
                );

        top.setBackground(
                Color.WHITE
        );

        top.setBorder(
                new EmptyBorder(
                        8,
                        14,
                        8,
                        14
                )
        );


        status.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        13
                )
        );

        status.setForeground(
                new Color(
                        100,
                        116,
                        139
                )
        );


        top.add(
                status,
                BorderLayout.WEST
        );


        // =====================================================
        // LOGOUT BUTTON
        // =====================================================

        // =====================================================
// LOGOUT BUTTON
// =====================================================

JButton logout = new JButton("Logout");

logout.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                14
        )
);

logout.setForeground(Color.WHITE);

logout.setBackground(
        new Color(
                31,
                41,
                55
        )
);

logout.setPreferredSize(
        new Dimension(
                105,
                38
        )
);

logout.setBorder(
        BorderFactory.createEmptyBorder(
                8,
                20,
                8,
                20
        )
);

logout.setFocusPainted(false);

logout.setOpaque(true);

logout.setCursor(
        new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
        )
);

logout.addActionListener(
        e -> {
            new LoginFrame().setVisible(true);
            dispose();
        }
);

top.add(
        logout,
        BorderLayout.EAST
);

        // =====================================================
        // ADD COMPONENTS TO FRAME
        // =====================================================

        add(
                nav,
                BorderLayout.WEST
        );

        add(
                top,
                BorderLayout.NORTH
        );

        add(
                content,
                BorderLayout.CENTER
        );
    }


    // =========================================================
    // NAVIGATION BUTTON
    // =========================================================

    private void addNav(
            JPanel nav,
            String text,
            Runnable action
    ) {

        JButton b =
                new JButton(text);


        b.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );


        b.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        42
                )
        );


        b.setPreferredSize(
                new Dimension(
                        190,
                        42
                )
        );


        b.setHorizontalAlignment(
                SwingConstants.LEFT
        );


        b.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );


        b.setForeground(
                new Color(
                        51,
                        65,
                        85
                )
        );


        b.setBackground(
                Color.WHITE
        );


        b.setBorder(
                BorderFactory.createCompoundBorder(

                        BorderFactory.createLineBorder(
                                new Color(
                                        226,
                                        232,
                                        240
                                )
                        ),

                        new EmptyBorder(
                                8,
                                14,
                                8,
                                14
                        )
                )
        );


        b.setFocusPainted(false);

        b.setOpaque(true);


        b.addActionListener(
                e -> action.run()
        );


        nav.add(b);


        nav.add(
                Box.createVerticalStrut(6)
        );
    }


    // =========================================================
    // DASHBOARD
    // =========================================================

    private void showDashboard() {

        JPanel p =
                new JPanel(
                        new BorderLayout(
                                20,
                                20
                        )
                );


        p.setBackground(
                new Color(
                        245,
                        247,
                        252
                )
        );


        p.setBorder(
                new EmptyBorder(
                        25,
                        30,
                        25,
                        30
                )
        );


        // =====================================================
        // DASHBOARD HEADER
        // =====================================================

        JPanel head =
                new JPanel(
                        new BorderLayout()
                );


        head.setOpaque(false);


        JLabel title =
                new JLabel(
                        "Service Operations Dashboard"
                );


        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        30
                )
        );


        title.setForeground(
                new Color(
                        31,
                        41,
                        55
                )
        );


        JLabel sub =
                new JLabel(
                        "Manage customers, vehicles, bookings, "
                        + "invoices and spare parts efficiently."
                );


        sub.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );


        sub.setForeground(
                new Color(
                        107,
                        114,
                        128
                )
        );


        JPanel headingText =
                new JPanel();


        headingText.setLayout(
                new BoxLayout(
                        headingText,
                        BoxLayout.Y_AXIS
                )
        );


        headingText.setOpaque(false);


        headingText.add(
                title
        );


        headingText.add(
                Box.createVerticalStrut(5)
        );


        headingText.add(
                sub
        );


        head.add(
                headingText,
                BorderLayout.WEST
        );


        // =====================================================
        // STATISTIC CARDS
        // =====================================================

        JPanel cards =
                new JPanel(
                        new GridLayout(
                                1,
                                5,
                                16,
                                0
                        )
                );


        cards.setOpaque(false);


        // Customers
        cards.add(
                statCard(
                        "Customers",
                        count(
                                "SELECT COUNT(*) FROM customers"
                        ),
                        new Color(
                                219,
                                234,
                                254
                        ),
                        new Color(
                                37,
                                99,
                                235
                        )
                )
        );


        // Vehicles
        cards.add(
                statCard(
                        "Vehicles",
                        count(
                                "SELECT COUNT(*) FROM vehicles"
                        ),
                        new Color(
                                220,
                                252,
                                231
                        ),
                        new Color(
                                22,
                                163,
                                74
                        )
                )
        );


        // Bookings
        cards.add(
                statCard(
                        "Bookings",
                        count(
                                "SELECT COUNT(*) "
                                + "FROM service_bookings"
                        ),
                        new Color(
                                237,
                                233,
                                254
                        ),
                        new Color(
                                124,
                                58,
                                237
                        )
                )
        );


        // Invoices
        cards.add(
                statCard(
                        "Invoices",
                        count(
                                "SELECT COUNT(*) FROM invoices"
                        ),
                        new Color(
                                255,
                                237,
                                213
                        ),
                        new Color(
                                234,
                                88,
                                12
                        )
                )
        );


        // Spare Parts
        cards.add(
                statCard(
                        "Spare Parts",
                        count(
                                "SELECT COUNT(*) FROM spare_parts"
                        ),
                        new Color(
                                207,
                                250,
                                254
                        ),
                        new Color(
                                8,
                                145,
                                178
                        )
                )
        );


        // =====================================================
        // BODY
        //
        // The cards are placed at NORTH inside body.
        // This prevents BorderLayout.CENTER from stretching
        // them to the entire screen.
        // =====================================================

        JPanel body =
                new JPanel(
                        new BorderLayout(
                                20,
                                20
                        )
                );


        body.setOpaque(false);


        cards.setPreferredSize(
                new Dimension(
                        0,
                        165
                )
        );


        body.add(
                cards,
                BorderLayout.NORTH
        );


        // =====================================================
        // WELCOME PANEL
        // =====================================================

        JPanel welcomePanel =
                new JPanel(
                        new BorderLayout()
                );


        welcomePanel.setBackground(
                Color.WHITE
        );


        welcomePanel.setBorder(
                BorderFactory.createCompoundBorder(

                        BorderFactory.createLineBorder(
                                new Color(
                                        226,
                                        232,
                                        240
                                )
                        ),

                        new EmptyBorder(
                                25,
                                25,
                                25,
                                25
                        )
                )
        );


        JLabel welcomeTitle =
                new JLabel(
                        "Service Management Overview"
                );


        welcomeTitle.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        21
                )
        );


        welcomeTitle.setForeground(
                new Color(
                        79,
                        70,
                        229
                )
        );


        JLabel welcomeText =
                new JLabel(
                        "Use the navigation panel to manage "
                        + "your vehicle service operations."
                );


        welcomeText.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );


        welcomeText.setForeground(
                new Color(
                        100,
                        116,
                        139
                )
        );


        JPanel welcomeTextPanel =
                new JPanel();


        welcomeTextPanel.setLayout(
                new BoxLayout(
                        welcomeTextPanel,
                        BoxLayout.Y_AXIS
                )
        );


        welcomeTextPanel.setOpaque(false);


        welcomeTextPanel.add(
                welcomeTitle
        );


        welcomeTextPanel.add(
                Box.createVerticalStrut(8)
        );


        welcomeTextPanel.add(
                welcomeText
        );


        welcomePanel.add(
                welcomeTextPanel,
                BorderLayout.WEST
        );


        body.add(
                welcomePanel,
                BorderLayout.CENTER
        );


        // =====================================================
        // ADD EVERYTHING TO DASHBOARD
        // =====================================================

        p.add(
                head,
                BorderLayout.NORTH
        );


        p.add(
                body,
                BorderLayout.CENTER
        );


        // =====================================================
        // REFRESH
        // =====================================================

        content.removeAll();


        content.add(
                p,
                BorderLayout.CENTER
        );


        content.revalidate();

        content.repaint();
    }


    // =========================================================
    // STATISTIC CARD
    // =========================================================

    private JPanel statCard(
            String label,
            String value,
            Color backgroundColor,
            Color accentColor
    ) {

        JPanel card =
                new JPanel(
                        new BorderLayout()
                );


        card.setBackground(
                backgroundColor
        );


        card.setBorder(
                BorderFactory.createCompoundBorder(

                        BorderFactory.createLineBorder(
                                new Color(
                                        accentColor.getRed(),
                                        accentColor.getGreen(),
                                        accentColor.getBlue(),
                                        90
                                ),
                                1
                        ),

                        new EmptyBorder(
                                18,
                                18,
                                15,
                                18
                        )
                )
        );


        // =====================================================
        // CARD TITLE
        // =====================================================

        JLabel title =
                new JLabel(
                        label
                );


        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        15
                )
        );


        title.setForeground(
                accentColor
        );


        // =====================================================
        // NUMBER
        // =====================================================

        JLabel number =
                new JLabel(
                        value
                );


        number.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        34
                )
        );


        number.setForeground(
                accentColor
        );


        // =====================================================
        // DESCRIPTION
        // =====================================================

        JLabel description =
                new JLabel(
                        "Total " + label
                );


        description.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        12
                )
        );


        description.setForeground(
                new Color(
                        75,
                        85,
                        99
                )
        );


        // =====================================================
        // ADD COMPONENTS
        // =====================================================

        card.add(
                title,
                BorderLayout.NORTH
        );


        card.add(
                number,
                BorderLayout.CENTER
        );


        card.add(
                description,
                BorderLayout.SOUTH
        );


        return card;
    }


    // =========================================================
    // ORACLE COUNT
    // =========================================================

    private String count(
            String sql
    ) {

        try (
                Connection c =
                        OracleConnection.getConnection();

                Statement st =
                        c.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            return rs.next()
                    ? rs.getString(1)
                    : "0";

        } catch (SQLException ex) {

            return "—";
        }
    }


    // =========================================================
    // OPEN ORACLE CRUD
    // =========================================================

    private void openCrud(
            String type
    ) {

        new OracleCrudFrame(type)
                .setVisible(true);
    }


    // =========================================================
    // CONNECTION TEST
    // =========================================================

    private void connectionDialog() {

        boolean oracleConnected =
                OracleConnection.testConnection();


        boolean mongoConnected =
                MongoConnection.testConnection();


        JOptionPane.showMessageDialog(
                this,

                "Oracle: "
                + (
                        oracleConnected
                        ? "CONNECTED"
                        : "NOT CONNECTED"
                )

                + "\nMongoDB: "
                + (
                        mongoConnected
                        ? "CONNECTED"
                        : "NOT CONNECTED"
                )

                + "\n\nOracle URL: "
                + DBConfig.ORACLE_URL

                + "\nMongo URI: "
                + DBConfig.MONGO_URI,

                "Database Status",

                JOptionPane.INFORMATION_MESSAGE
        );
    }
}