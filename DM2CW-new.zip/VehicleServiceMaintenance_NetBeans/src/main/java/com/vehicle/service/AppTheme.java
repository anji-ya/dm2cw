package com.vehicle.service;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public final class AppTheme {
    // Light UI with dark, readable text throughout the application.
    public static final Color NAVY = new Color(238, 242, 247);       // light navigation background
    public static final Color BLUE = new Color(219, 234, 254);       // light button/accent background
    public static final Color LIGHT = new Color(248, 250, 252);     // main background
    public static final Color WHITE = Color.WHITE;                   // cards/forms
    public static final Color TEXT = new Color(31, 41, 55);         // dark primary text
    public static final Color MUTED = new Color(75, 85, 99);        // dark secondary text
    public static final Color GREEN = new Color(22, 101, 52);       // dark green
    public static final Color RED = new Color(153, 27, 27);         // dark red
    public static final Color BORDER = new Color(203, 213, 225);

    private AppTheme() {}

    public static void apply() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        // Keep standard Swing controls light with dark text.
        UIManager.put("Panel.background", LIGHT);
        UIManager.put("OptionPane.background", WHITE);
        UIManager.put("OptionPane.messageForeground", TEXT);
        UIManager.put("Label.foreground", TEXT);
        UIManager.put("TextField.background", WHITE);
        UIManager.put("TextField.foreground", TEXT);
        UIManager.put("PasswordField.background", WHITE);
        UIManager.put("PasswordField.foreground", TEXT);
        UIManager.put("TextArea.background", WHITE);
        UIManager.put("TextArea.foreground", TEXT);
        UIManager.put("ComboBox.background", WHITE);
        UIManager.put("ComboBox.foreground", TEXT);
        UIManager.put("Table.background", WHITE);
        UIManager.put("Table.foreground", TEXT);
        UIManager.put("Table.gridColor", BORDER);
        UIManager.put("Table.selectionBackground", new Color(219, 234, 254));
        UIManager.put("Table.selectionForeground", TEXT);
        UIManager.put("ScrollPane.background", LIGHT);
    }

    public static JButton button(String text) {
        JButton b = new JButton(text);
        b.setFocusPainted(false);
        b.setBackground(BLUE);
        b.setForeground(TEXT);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(147, 197, 253)),
                new EmptyBorder(9, 15, 9, 15)
        ));
        return b;
    }

    public static JLabel title(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 24));
        l.setForeground(TEXT);
        return l;
    }

    public static JPanel card() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER),
                new EmptyBorder(16, 16, 16, 16)
        ));
        return p;
    }
}
