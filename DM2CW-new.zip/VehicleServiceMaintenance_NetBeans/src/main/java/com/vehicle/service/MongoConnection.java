package com.vehicle.service;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public final class MongoConnection {
    private static MongoClient client;

    private MongoConnection() {}

    public static synchronized MongoDatabase getDatabase() {
        if (client == null) {
            client = MongoClients.create(DBConfig.MONGO_URI);
        }
        return client.getDatabase(DBConfig.MONGO_DATABASE);
    }

    public static boolean testConnection() {
        try {
            getDatabase().runCommand(new org.bson.Document("ping", 1));
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    public static synchronized void close() {
        if (client != null) {
            client.close();
            client = null;
        }
    }
}
