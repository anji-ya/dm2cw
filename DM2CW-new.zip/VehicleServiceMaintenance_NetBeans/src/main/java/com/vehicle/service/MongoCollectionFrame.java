
package com.vehicle.service;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import java.awt.print.PrinterJob;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.FontMetrics;
import java.awt.GridLayout;

import java.io.FileOutputStream;
import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import org.bson.Document;
import org.bson.types.ObjectId;

public class MongoCollectionFrame extends JFrame {

    private final String collectionName;
    private final MongoCollection<Document> collection;

    private JTable table;
    private DefaultTableModel model;

    private final List<Document> documents = new ArrayList<>();

    public MongoCollectionFrame(String title, String collectionName) {

        this.collectionName = collectionName;

        MongoDatabase db = MongoConnection.getDatabase();
        this.collection = db.getCollection(collectionName);

        setTitle(title + " - MongoDB");
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        if ("service_records".equals(collectionName)) {
            createJobCardInterface();
        } else {
            createGenericInterface(title);
        }

        load();
    }

    // ============================================================
    // JOB CARD INTERFACE
    // ============================================================

    private void createJobCardInterface() {

        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBackground(Color.WHITE);
        main.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);

        JLabel title = new JLabel("Vehicle Service Job Cards");
        title.setFont(new java.awt.Font(
                "Segoe UI",
                java.awt.Font.BOLD,
                24
        ));

        JLabel subtitle = new JLabel(
                "MongoDB Service Records"
        );

        subtitle.setForeground(Color.GRAY);

        JPanel titlePanel = new JPanel(new GridLayout(2, 1));
        titlePanel.setBackground(Color.WHITE);
        titlePanel.add(title);
        titlePanel.add(subtitle);

        header.add(titlePanel, BorderLayout.WEST);

        JPanel buttons = new JPanel(
                new FlowLayout(FlowLayout.RIGHT)
        );
        buttons.setBackground(Color.WHITE);

        JButton refresh = new JButton("Refresh");
        JButton view = new JButton("View Job Card");
        JButton add = new JButton("Add Document");
        JButton delete = new JButton("Delete Selected");

        refresh.addActionListener(e -> {
    load();
    JOptionPane.showMessageDialog(
            this,
            "Data refreshed successfully.",
            "Refresh",
            JOptionPane.INFORMATION_MESSAGE
    );
});

        view.addActionListener(e -> viewSelectedJobCard());

        add.addActionListener(e -> addDocument());

        delete.addActionListener(e -> deleteDocument());

        buttons.add(refresh);
        buttons.add(view);
        buttons.add(add);
        buttons.add(delete);

        header.add(buttons, BorderLayout.EAST);

        main.add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(
                new Object[]{
                    "Job Card",
                    "Vehicle ID",
                    "Registration",
                    "Customer ID",
                    "Service Date",
                    "Service Type",
                    "Technician",
                    "Status",
                    "Mileage"
                },
                0
        ) {
            @Override
            public boolean isCellEditable(
                    int row,
                    int column
            ) {
                return false;
            }
        };

        table = new JTable(model);

        table.setRowHeight(32);
        table.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        table.setFont(new java.awt.Font(
                "Segoe UI",
                java.awt.Font.PLAIN,
                13
        ));

        table.getTableHeader().setFont(
                new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.BOLD,
                        13
                )
        );

        table.setAutoCreateRowSorter(true);

        main.add(
                new JScrollPane(table),
                BorderLayout.CENTER
        );

        JLabel footer = new JLabel(
                "Select a job card and click 'View Job Card' to generate the service document.",
                SwingConstants.LEFT
        );

        footer.setForeground(Color.GRAY);

        main.add(footer, BorderLayout.SOUTH);

        add(main);
    }

    // ============================================================
    // GENERIC MONGODB INTERFACE
    // ============================================================

    private void createGenericInterface(String title) {

        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBackground(Color.WHITE);

        main.setBorder(
                BorderFactory.createEmptyBorder(
                        15,
                        15,
                        15,
                        15
                )
        );

        JLabel heading = new JLabel(title);

        heading.setFont(
                new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.BOLD,
                        24
                )
        );

        main.add(heading, BorderLayout.NORTH);

        JTextArea output = new JTextArea();

        output.setEditable(false);
        output.setFont(
                new java.awt.Font(
                        "Consolas",
                        java.awt.Font.PLAIN,
                        13
                )
        );

        main.add(
                new JScrollPane(output),
                BorderLayout.CENTER
        );

        add(main);
    }

    // ============================================================
    // LOAD DATA
    // ============================================================

    private void load() {
    try {
        documents.clear();

        for (Document d : collection.find()
                .sort(new Document("_id", -1))
                .limit(100)) {

            documents.add(d);
        }

        if ("service_records".equals(collectionName)) {
            loadJobCards();
        }

        // Force the table to update
        if (table != null) {
            table.revalidate();
            table.repaint();
        }

    } catch (Exception ex) {
        JOptionPane.showMessageDialog(
                this,
                "MongoDB refresh failed:\n" + ex.getMessage(),
                "Refresh Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
    // ============================================================
    // LOAD JOB CARDS INTO TABLE
    // ============================================================

    private void loadJobCards() {

        model.setRowCount(0);

        for (Document d : documents) {

            Document technician =
                    d.get("technician", Document.class);

            String technicianName = "";

            if (technician != null) {

                technicianName =
                        technician.getString("name");

                if (technicianName == null) {
                    technicianName =
                            technician.toJson();
                }
            }

            model.addRow(
                    new Object[]{
                        d.getString("jobCardNo"),
                        d.get("vehicleId"),
                        d.getString("registrationNo"),
                        d.get("customerId"),
                        d.getString("serviceDate"),
                        d.getString("serviceType"),
                        technicianName,
                        d.getString("status"),
                        d.get("mileage")
                    }
            );
        }
    }

    // ============================================================
    // VIEW SELECTED JOB CARD
    // ============================================================

    private void viewSelectedJobCard() {

        int row = table.getSelectedRow();

        if (row < 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a job card first.",
                    "Job Card",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int modelRow =
                table.convertRowIndexToModel(row);

        Document selected =
                documents.get(modelRow);

        showJobCardDocument(selected);
    }

    // ============================================================
    // PROFESSIONAL JOB CARD PREVIEW
    // ============================================================

    private void showJobCardDocument(Document d) {

    JFrame frame = new JFrame("Vehicle Service Job Card");
    frame.setSize(900, 750);
    frame.setLocationRelativeTo(this);
    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    JPanel main = new JPanel(new BorderLayout());
    main.setBackground(new Color(245, 247, 250));
    main.setBorder(
            javax.swing.BorderFactory.createEmptyBorder(
                    15, 15, 15, 15
            )
    );

    // =========================================================
    // HEADER
    // =========================================================

    JPanel header = new JPanel(new BorderLayout());
    header.setBackground(new Color(20, 42, 74));
    header.setBorder(
            javax.swing.BorderFactory.createEmptyBorder(
                    18, 25, 18, 25
            )
    );

    JPanel companyPanel = new JPanel(
            new GridLayout(2, 1)
    );
    companyPanel.setOpaque(false);

    JLabel company = new JLabel("VSM SERVICE NETWORK");
    company.setForeground(Color.WHITE);
    company.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    24
            )
    );

    JLabel system = new JLabel(
            "Vehicle Service & Maintenance Management System"
    );
    system.setForeground(Color.WHITE);
    system.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.PLAIN,
                    13
            )
    );

    companyPanel.add(company);
    companyPanel.add(system);

    JLabel jobTitle = new JLabel(
            "VEHICLE JOB CARD",
            SwingConstants.RIGHT
    );

    jobTitle.setForeground(Color.WHITE);
    jobTitle.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    20
            )
    );

    header.add(companyPanel, BorderLayout.WEST);
    header.add(jobTitle, BorderLayout.EAST);

    main.add(header, BorderLayout.NORTH);

    // =========================================================
    // DOCUMENT BODY
    // =========================================================

    JPanel body = new JPanel();
    body.setBackground(Color.WHITE);
    body.setBorder(
            javax.swing.BorderFactory.createEmptyBorder(
                    20, 25, 20, 25
            )
    );

    body.setLayout(
            new BoxLayout(body, BoxLayout.Y_AXIS)
    );

    // ---------------------------------------------------------
    // JOB CARD SUMMARY
    // ---------------------------------------------------------

    JPanel summary = createSectionPanel(
            "JOB CARD INFORMATION"
    );

    addDetailRow(
            summary,
            "Job Card No",
            safe(d.getString("jobCardNo")),
            "Service Date",
            safe(d.getString("serviceDate"))
    );

    addDetailRow(
            summary,
            "Service Type",
            safe(d.getString("serviceType")),
            "Status",
            safe(d.getString("status"))
    );

    body.add(summary);
    body.add(javax.swing.Box.createVerticalStrut(12));

    // ---------------------------------------------------------
    // CUSTOMER / VEHICLE
    // ---------------------------------------------------------

    JPanel vehiclePanel = createSectionPanel(
            "CUSTOMER & VEHICLE INFORMATION"
    );

    addDetailRow(
            vehiclePanel,
            "Customer ID",
            safe(d.get("customerId")),
            "Vehicle ID",
            safe(d.get("vehicleId"))
    );

    addDetailRow(
            vehiclePanel,
            "Registration No",
            safe(d.getString("registrationNo")),
            "Mileage",
            safe(d.get("mileage")) + " km"
    );

    addDetailRow(
            vehiclePanel,
            "Service Booking ID",
            safe(d.get("serviceBookingId")),
            "",
            ""
    );

    body.add(vehiclePanel);
    body.add(javax.swing.Box.createVerticalStrut(12));

    // ---------------------------------------------------------
    // TECHNICIAN
    // ---------------------------------------------------------

    JPanel technicianPanel = createSectionPanel(
            "TECHNICIAN INFORMATION"
    );

    Document technician =
            d.get("technician", Document.class);

    String technicianName = "";
    String technicianId = "";

    if (technician != null) {

        technicianName =
                safe(technician.getString("name"));

        technicianId =
                safe(technician.get("id"));
    }

    addDetailRow(
            technicianPanel,
            "Technician",
            technicianName,
            "Technician ID",
            technicianId
    );

    body.add(technicianPanel);
    body.add(javax.swing.Box.createVerticalStrut(12));

    // ---------------------------------------------------------
    // TECHNICIAN NOTES
    // ---------------------------------------------------------

    JPanel notesPanel = createSectionPanel(
            "TECHNICIAN NOTES"
    );

    List<?> notes =
            d.getList(
                    "technicianNotes",
                    Object.class
            );

    if (notes != null && !notes.isEmpty()) {

        for (Object note : notes) {

            JLabel noteLabel = new JLabel(
                    "• " + note.toString()
            );

            noteLabel.setFont(
                    new java.awt.Font(
                            "Segoe UI",
                            java.awt.Font.PLAIN,
                            13
                    )
            );

            notesPanel.add(noteLabel);
        }

    } else {

        notesPanel.add(
                new JLabel("No technician notes recorded.")
        );
    }

    body.add(notesPanel);
    body.add(javax.swing.Box.createVerticalStrut(12));

    // ---------------------------------------------------------
    // PARTS USED
    // ---------------------------------------------------------

    JPanel partsPanel = createSectionPanel(
            "PARTS USED"
    );

    List<?> parts =
            d.getList(
                    "partsUsed",
                    Object.class
            );

    if (parts != null && !parts.isEmpty()) {

        for (Object part : parts) {

            JLabel partLabel = new JLabel(
                    "• " + part.toString()
            );

            partLabel.setFont(
                    new java.awt.Font(
                            "Segoe UI",
                            java.awt.Font.PLAIN,
                            13
                    )
            );

            partsPanel.add(partLabel);
        }

    } else {

        partsPanel.add(
                new JLabel("No parts recorded.")
        );
    }

    body.add(partsPanel);
    body.add(javax.swing.Box.createVerticalStrut(12));

    // ---------------------------------------------------------
    // SERVICE HISTORY
    // ---------------------------------------------------------

    JPanel historyPanel = createSectionPanel(
            "SERVICE HISTORY"
    );

    Document history =
            d.get(
                    "serviceHistory",
                    Document.class
            );

    if (history != null) {

        for (String key : history.keySet()) {

            addHistoryRow(
                    historyPanel,
                    key,
                    safe(history.get(key))
            );
        }

    } else {

        historyPanel.add(
                new JLabel("No service history available.")
        );
    }

    body.add(historyPanel);
    body.add(javax.swing.Box.createVerticalStrut(15));

    // ---------------------------------------------------------
    // SIGNATURES
    // ---------------------------------------------------------

    JPanel signatures =
            new JPanel(new GridLayout(1, 2, 40, 0));

    signatures.setBackground(Color.WHITE);

    signatures.setBorder(
            javax.swing.BorderFactory.createEmptyBorder(
                    15, 10, 10, 10
            )
    );

    JLabel technicianSignature =
            new JLabel(
                    "<html>Technician Signature:<br/><br/>"
                    + "____________________________</html>"
            );

    JLabel customerSignature =
            new JLabel(
                    "<html>Customer Signature:<br/><br/>"
                    + "____________________________</html>"
            );

    technicianSignature.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.PLAIN,
                    13
            )
    );

    customerSignature.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.PLAIN,
                    13
            )
    );

    signatures.add(technicianSignature);
    signatures.add(customerSignature);

    body.add(signatures);

    JScrollPane scroll =
            new JScrollPane(body);

    scroll.setBorder(null);

    main.add(scroll, BorderLayout.CENTER);

    // =========================================================
    // BUTTONS
    // =========================================================

    JPanel buttons =
            new JPanel(
                    new FlowLayout(
                            FlowLayout.RIGHT
                    )
            );

    buttons.setBackground(Color.WHITE);

    JButton export =
            new JButton("Export PDF");

    JButton print =
            new JButton("Print");

    JButton close =
            new JButton("Close");

    export.setPreferredSize(
            new Dimension(120, 35)
    );

    print.setPreferredSize(
            new Dimension(100, 35)
    );

    close.setPreferredSize(
            new Dimension(100, 35)
    );

    export.addActionListener(
            e -> exportPDF(d)
    );

    print.addActionListener(e -> {

    try {

        PrinterJob job = PrinterJob.getPrinterJob();

        job.setJobName("Vehicle Service Job Card");

        job.setPrintable((graphics, pageFormat, pageIndex) -> {

            if (pageIndex > 0) {
                return java.awt.print.Printable.NO_SUCH_PAGE;
            }

            java.awt.Graphics2D g2 =
                    (java.awt.Graphics2D) graphics;

            double scaleX =
                    pageFormat.getImageableWidth()
                    / body.getWidth();

            double scaleY =
                    pageFormat.getImageableHeight()
                    / body.getHeight();

            double scale =
                    Math.min(scaleX, scaleY);

            if (scale > 1.0) {
                scale = 1.0;
            }

            g2.translate(
                    pageFormat.getImageableX(),
                    pageFormat.getImageableY()
            );

            g2.scale(scale, scale);

            body.printAll(g2);

            return java.awt.print.Printable.PAGE_EXISTS;
        });

        if (job.printDialog()) {

            job.print();

            JOptionPane.showMessageDialog(
                    frame,
                    "Job Card sent to printer.",
                    "Print",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }

    } catch (Exception ex) {

        JOptionPane.showMessageDialog(
                frame,
                "Unable to print:\n" + ex.getMessage(),
                "Print Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
});

    close.addActionListener(
            e -> frame.dispose()
    );

    buttons.add(export);
    buttons.add(print);
    buttons.add(close);

    main.add(buttons, BorderLayout.SOUTH);

    frame.add(main);
    frame.setVisible(true);
}
    // ============================================================
    // EXPORT JOB CARD TO PDF
    // ============================================================
private JPanel createSectionPanel(String title) {

    JPanel panel =
            new JPanel();

    panel.setBackground(Color.WHITE);

    panel.setLayout(
            new BoxLayout(
                    panel,
                    BoxLayout.Y_AXIS
            )
    );

    panel.setBorder(
            javax.swing.BorderFactory.createCompoundBorder(
                    javax.swing.BorderFactory.createTitledBorder(
                            javax.swing.BorderFactory.createLineBorder(
                                    new Color(210, 215, 220)
                            ),
                            title
                    ),
                    javax.swing.BorderFactory.createEmptyBorder(
                            8, 12, 10, 12
                    )
            )
    );

    return panel;
}
private void addDetailRow(
        JPanel panel,
        String label1,
        String value1,
        String label2,
        String value2
) {

    JPanel row =
            new JPanel(
                    new GridLayout(1, 4, 10, 5)
            );

    row.setBackground(Color.WHITE);

    JLabel l1 =
            new JLabel(label1);

    l1.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    13
            )
    );

    JLabel v1 =
            new JLabel(value1);

    JLabel l2 =
            new JLabel(label2);

    l2.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    13
            )
    );

    JLabel v2 =
            new JLabel(value2);

    row.add(l1);
    row.add(v1);
    row.add(l2);
    row.add(v2);

    panel.add(row);
    panel.add(
            javax.swing.Box.createVerticalStrut(7)
    );
}
private void addHistoryRow(
        JPanel panel,
        String key,
        String value
) {

    JPanel row =
            new JPanel(
                    new GridLayout(1, 2, 10, 5)
            );

    row.setBackground(Color.WHITE);

    JLabel keyLabel =
            new JLabel(key);

    keyLabel.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    13
            )
    );

    JLabel valueLabel =
            new JLabel(value);

    row.add(keyLabel);
    row.add(valueLabel);

    panel.add(row);

    panel.add(
            javax.swing.Box.createVerticalStrut(5)
    );
}
    private void exportPDF(Document d) {

        JFileChooser chooser =
                new JFileChooser();

        chooser.setDialogTitle(
                "Save Vehicle Job Card"
        );

        String jobCard =
                d.getString("jobCardNo");

        if (jobCard == null ||
                jobCard.isBlank()) {

            jobCard = "Vehicle_Job_Card";
        }

        chooser.setSelectedFile(
                new java.io.File(
                        jobCard + ".pdf"
                )
        );

        int result =
                chooser.showSaveDialog(this);

        if (result != JFileChooser.APPROVE_OPTION) {
            return;
        }

        java.io.File file =
                chooser.getSelectedFile();

        if (!file.getName()
                .toLowerCase()
                .endsWith(".pdf")) {

            file = new java.io.File(
                    file.getAbsolutePath() + ".pdf"
            );
        }

        try {

            com.lowagie.text.Document pdf =
                    new com.lowagie.text.Document(
                            PageSize.A4,
                            40,
                            40,
                            40,
                            40
                    );

            PdfWriter.getInstance(
                    pdf,
                    new FileOutputStream(file)
            );

            pdf.open();

            Font titleFont =
                    new Font(
                            Font.HELVETICA,
                            18,
                            Font.BOLD
                    );

            Font headingFont =
                    new Font(
                            Font.HELVETICA,
                            12,
                            Font.BOLD
                    );

            Font normalFont =
                    new Font(
                            Font.HELVETICA,
                            10
                    );

            Paragraph company =
                    new Paragraph(
                            "VSM SERVICE NETWORK",
                            titleFont
                    );

            company.setAlignment(
                    Element.ALIGN_CENTER
            );

            pdf.add(company);

            Paragraph subtitle =
                    new Paragraph(
                            "VEHICLE SERVICE & MAINTENANCE SYSTEM",
                            normalFont
                    );

            subtitle.setAlignment(
                    Element.ALIGN_CENTER
            );

            pdf.add(subtitle);

            pdf.add(
                    new Paragraph(" ")
            );

            Paragraph jobTitle =
                    new Paragraph(
                            "VEHICLE SERVICE JOB CARD",
                            headingFont
                    );

            jobTitle.setAlignment(
                    Element.ALIGN_CENTER
            );

            pdf.add(jobTitle);

            pdf.add(
                    new Paragraph(" ")
            );

            PdfPTable info =
                    new PdfPTable(2);

            info.setWidthPercentage(100);

            addCell(
                    info,
                    "Job Card No",
                    headingFont
            );

            addCell(
                    info,
                    safe(d.getString("jobCardNo")),
                    normalFont
            );

            addCell(
                    info,
                    "Service Date",
                    headingFont
            );

            addCell(
                    info,
                    safe(d.getString("serviceDate")),
                    normalFont
            );

            addCell(
                    info,
                    "Service Type",
                    headingFont
            );

            addCell(
                    info,
                    safe(d.getString("serviceType")),
                    normalFont
            );

            addCell(
                    info,
                    "Status",
                    headingFont
            );

            addCell(
                    info,
                    safe(d.getString("status")),
                    normalFont
            );

            addCell(
                    info,
                    "Registration No",
                    headingFont
            );

            addCell(
                    info,
                    safe(d.getString("registrationNo")),
                    normalFont
            );

            addCell(
                    info,
                    "Vehicle ID",
                    headingFont
            );

            addCell(
                    info,
                    safe(d.get("vehicleId")),
                    normalFont
            );

            addCell(
                    info,
                    "Customer ID",
                    headingFont
            );

            addCell(
                    info,
                    safe(d.get("customerId")),
                    normalFont
            );

            addCell(
                    info,
                    "Mileage",
                    headingFont
            );

            addCell(
                    info,
                    safe(d.get("mileage")) + " km",
                    normalFont
            );

            pdf.add(info);

            pdf.add(
                    new Paragraph(" ")
            );

            pdf.add(
                    new Paragraph(
                            "TECHNICIAN INFORMATION",
                            headingFont
                    )
            );

            Document technician =
                    d.get(
                            "technician",
                            Document.class
                    );

            if (technician != null) {

                pdf.add(
                        new Paragraph(
                                "Technician: "
                                + safe(
                                        technician.getString(
                                                "name"
                                        )
                                ),
                                normalFont
                        )
                );

                pdf.add(
                        new Paragraph(
                                "Technician ID: "
                                + safe(
                                        technician.get("id")
                                ),
                                normalFont
                        )
                );
            }

            pdf.add(
                    new Paragraph(" ")
            );

            pdf.add(
                    new Paragraph(
                            "TECHNICIAN NOTES",
                            headingFont
                    )
            );

            List<?> notes =
                    d.getList(
                            "technicianNotes",
                            Object.class
                    );

            if (notes != null &&
                    !notes.isEmpty()) {

                for (Object note : notes) {

                    pdf.add(
                            new Paragraph(
                                    "• "
                                    + note.toString(),
                                    normalFont
                            )
                    );
                }

            } else {

                pdf.add(
                        new Paragraph(
                                "No technician notes available.",
                                normalFont
                        )
                );
            }

            pdf.add(
                    new Paragraph(" ")
            );

            pdf.add(
                    new Paragraph(
                            "PARTS USED",
                            headingFont
                    )
            );

            List<?> parts =
                    d.getList(
                            "partsUsed",
                            Object.class
                    );

            if (parts != null &&
                    !parts.isEmpty()) {

                for (Object part : parts) {

                    pdf.add(
                            new Paragraph(
                                    "• "
                                    + part.toString(),
                                    normalFont
                            )
                    );
                }

            } else {

                pdf.add(
                        new Paragraph(
                                "No parts recorded.",
                                normalFont
                        )
                );
            }

            pdf.add(
                    new Paragraph(" ")
            );

            pdf.add(
                    new Paragraph(
                            "SERVICE HISTORY",
                            headingFont
                    )
            );

            Document history =
                    d.get(
                            "serviceHistory",
                            Document.class
                    );

            if (history != null) {

                for (String key :
                        history.keySet()) {

                    pdf.add(
                            new Paragraph(
                                    key
                                    + " : "
                                    + safe(
                                            history.get(key)
                                    ),
                                    normalFont
                            )
                    );
                }

            } else {

                pdf.add(
                        new Paragraph(
                                "No service history available.",
                                normalFont
                        )
                );
            }

            pdf.add(
                    new Paragraph("\n\n")
            );

            PdfPTable signatures =
                    new PdfPTable(2);

            signatures.setWidthPercentage(100);

            addCell(
                    signatures,
                    "Technician Signature:\n\n________________________",
                    normalFont
            );

            addCell(
                    signatures,
                    "Customer Signature:\n\n________________________",
                    normalFont
            );

            pdf.add(signatures);

            pdf.add(
                    new Paragraph("\n")
            );

            Paragraph footer =
                    new Paragraph(
                            "Generated by VSM Service Network",
                            normalFont
                    );

            footer.setAlignment(
                    Element.ALIGN_CENTER
            );

            pdf.add(footer);

            pdf.close();

            JOptionPane.showMessageDialog(
                    this,
                    "Job Card PDF exported successfully:\n"
                    + file.getAbsolutePath(),
                    "Export Successful",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (
                IOException |
                DocumentException ex
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to export PDF:\n"
                    + ex.getMessage(),
                    "PDF Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ============================================================
    // PDF CELL HELPER
    // ============================================================

    private void addCell(
            PdfPTable table,
            String text,
            Font font
    ) {

        PdfPCell cell =
                new PdfPCell(
                        new Phrase(
                                text,
                                font
                        )
                );

        cell.setPadding(8);

        table.addCell(cell);
    }

    // ============================================================
    // ADD DOCUMENT
    // ============================================================

    private void addDocument() {

        if (!"service_records".equals(collectionName)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Add Document can be implemented for this collection next.",
                    "MongoDB",
                    JOptionPane.INFORMATION_MESSAGE
            );

            return;
        }

        try {

            String vehicleId =
                    JOptionPane.showInputDialog(
                            this,
                            "Vehicle ID:"
                    );

            if (vehicleId == null) {
                return;
            }

            String registration =
                    JOptionPane.showInputDialog(
                            this,
                            "Vehicle Registration:"
                    );

            if (registration == null) {
                return;
            }

            String customerId =
                    JOptionPane.showInputDialog(
                            this,
                            "Customer ID:"
                    );

            if (customerId == null) {
                return;
            }

            String jobCardNo =
                    JOptionPane.showInputDialog(
                            this,
                            "Job Card No:",
                            "JC-2026-003"
                    );

            if (jobCardNo == null) {
                return;
            }

            String serviceDate =
                    JOptionPane.showInputDialog(
                            this,
                            "Service Date (YYYY-MM-DD):",
                            "2026-08-20"
                    );

            if (serviceDate == null) {
                return;
            }

            String serviceType =
                    JOptionPane.showInputDialog(
                            this,
                            "Service Type:",
                            "General Service"
                    );

            if (serviceType == null) {
                return;
            }

            String status =
                    JOptionPane.showInputDialog(
                            this,
                            "Status:",
                            "BOOKED"
                    );

            if (status == null) {
                return;
            }

            String mileage =
                    JOptionPane.showInputDialog(
                            this,
                            "Mileage:",
                            "50000"
                    );

            if (mileage == null) {
                return;
            }

            String technician =
                    JOptionPane.showInputDialog(
                            this,
                            "Technician Name:",
                            "Technician"
                    );

            if (technician == null) {
                return;
            }

            Document technicianDoc =
                    new Document()
                            .append("name", technician);

            Document d =
                    new Document()
                            .append(
                                    "vehicleId",
                                    Integer.parseInt(vehicleId)
                            )
                            .append(
                                    "registrationNo",
                                    registration
                            )
                            .append(
                                    "customerId",
                                    Integer.parseInt(customerId)
                            )
                            .append(
                                    "jobCardNo",
                                    jobCardNo
                            )
                            .append(
                                    "serviceDate",
                                    serviceDate
                            )
                            .append(
                                    "serviceType",
                                    serviceType
                            )
                            .append(
                                    "technician",
                                    technicianDoc
                            )
                            .append(
                                    "status",
                                    status
                            )
                            .append(
                                    "mileage",
                                    Integer.parseInt(mileage)
                            )
                            .append(
                                    "technicianNotes",
                                    new ArrayList<>()
                            )
                            .append(
                                    "partsUsed",
                                    new ArrayList<>()
                            )
                            .append(
                                    "createdAt",
                                    new SimpleDateFormat(
                                            "yyyy-MM-dd'T'HH:mm:ss"
                                    ).format(new Date())
                            );

            collection.insertOne(d);

            load();

            JOptionPane.showMessageDialog(
                    this,
                    "Job Card added successfully.",
                    "MongoDB",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to add job card:\n"
                    + ex.getMessage(),
                    "MongoDB Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ============================================================
    // DELETE
    // ============================================================

    private void deleteDocument() {

        int row = table.getSelectedRow();

        if (row < 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a job card first."
            );

            return;
        }

        int modelRow =
                table.convertRowIndexToModel(row);

        Document selected =
                documents.get(modelRow);

        Object id =
                selected.get("_id");

        int confirm =
                JOptionPane.showConfirmDialog(
                        this,
                        "Delete selected job card?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION
                );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            collection.deleteOne(
                    Filters.eq(
                            "_id",
                            id
                    )
            );

            load();

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Delete failed:\n"
                    + ex.getMessage(),
                    "MongoDB",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ============================================================
    // SAFE VALUE
    // ============================================================

    private String safe(Object value) {

        if (value == null) {
            return "";
        }

        return String.valueOf(value);
    }
}