package com.vehicle.service;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;

import org.bson.Document;
import org.bson.types.ObjectId;

public class CustomerComplaintsFrame extends JFrame {

    private final MongoCollection<Document> collection;

    private JTable table;
    private DefaultTableModel model;
    private JTextField searchField;

    public CustomerComplaintsFrame() {

        MongoDatabase db = MongoConnection.getDatabase();

        collection = db.getCollection("customer_complaints");

        setTitle("Complaints & Feedback - MongoDB");
        setSize(1150, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        createInterface();
        loadRecords();
    }

    // =========================================================
    // INTERFACE
    // =========================================================

    private void createInterface() {

        JPanel main =
                new JPanel(new BorderLayout(10, 10));

        main.setBackground(Color.WHITE);

        main.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 15, 15, 15
                )
        );

        // -----------------------------------------------------
        // HEADER
        // -----------------------------------------------------

        JPanel header =
                new JPanel(new BorderLayout());

        header.setBackground(Color.WHITE);

        JLabel title =
                new JLabel("Complaints & Feedback");

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        24
                )
        );

        title.setForeground(
                new Color(31, 41, 55)
        );

        header.add(
                title,
                BorderLayout.WEST
        );

        // -----------------------------------------------------
        // BUTTONS
        // -----------------------------------------------------

        JPanel buttons =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.RIGHT,
                                8,
                                0
                        )
                );

        buttons.setBackground(Color.WHITE);

        searchField =
                new JTextField(14);

        searchField.setPreferredSize(
                new Dimension(150, 32)
        );

        JButton searchButton =
                new JButton("Search");

        JButton addButton =
                new JButton("Add Complaint");

        JButton viewButton =
                new JButton("View Details");

        JButton deleteButton =
                new JButton("Delete");

        JButton closeButton =
                new JButton("Close");

        searchButton.addActionListener(
                e -> searchRecords(
                        searchField.getText().trim()
                )
        );

        searchField.addActionListener(
                e -> searchRecords(
                        searchField.getText().trim()
                )
        );

        addButton.addActionListener(
                e -> addComplaint()
        );

        viewButton.addActionListener(
                e -> viewSelected()
        );

        deleteButton.addActionListener(
                e -> deleteSelected()
        );

        closeButton.addActionListener(
                e -> dispose()
        );

        buttons.add(searchField);
        buttons.add(searchButton);
        buttons.add(addButton);
        buttons.add(viewButton);
        buttons.add(deleteButton);
        buttons.add(closeButton);

        header.add(
                buttons,
                BorderLayout.EAST
        );

        // -----------------------------------------------------
        // TABLE
        // -----------------------------------------------------

        model =
                new DefaultTableModel(
                        new Object[]{
                                "Complaint ID",
                                "Customer ID",
                                "Vehicle ID",
                                "Registration",
                                "Complaint Type",
                                "Date",
                                "Status",
                                "Rating"
                        },
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column
                    ) {
                        return false;
                    }
                };

        table =
                new JTable(model);

        table.setRowHeight(32);

        table.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        table.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        13
                )
        );

        table.getTableHeader().setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        table.getTableHeader().setBackground(
                new Color(226, 232, 240)
        );

        table.getTableHeader().setForeground(
                new Color(31, 41, 55)
        );

        table.setAutoCreateRowSorter(true);

        // Double-click to view
        table.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    @Override
                    public void mouseClicked(
                            java.awt.event.MouseEvent e
                    ) {

                        if (e.getClickCount() == 2) {
                            viewSelected();
                        }
                    }
                }
        );

        JScrollPane scroll =
                new JScrollPane(table);

        scroll.setBorder(
                BorderFactory.createLineBorder(
                        new Color(210, 214, 220)
                )
        );

        // -----------------------------------------------------
        // FOOTER
        // -----------------------------------------------------

        JLabel footer =
                new JLabel(
                        "Select a complaint and click View Details.",
                        SwingConstants.LEFT
                );

        footer.setForeground(
                new Color(107, 114, 128)
        );

        main.add(
                header,
                BorderLayout.NORTH
        );

        main.add(
                scroll,
                BorderLayout.CENTER
        );

        main.add(
                footer,
                BorderLayout.SOUTH
        );

        add(main);
    }

    // =========================================================
    // LOAD RECORDS
    // =========================================================

    private void loadRecords() {

        model.setRowCount(0);

        try {

            for (Document d :
                    collection.find()
                            .sort(
                                    new Document(
                                            "_id",
                                            -1
                                    )
                            )
                            .limit(100)) {

                addRow(d);
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to load complaints:\n"
                    + ex.getMessage(),
                    "MongoDB Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =========================================================
    // ADD ROW
    // =========================================================

    private void addRow(Document d) {

    String complaintId;

    // Use complaintId if it exists
    String existingId = getValue(
            d,
            "complaintId",
            "complaint_id"
    );

    if (!existingId.isEmpty()) {
        complaintId = existingId;
    } else {
        // Generate a readable ID from MongoDB _id
        ObjectId objectId = d.getObjectId("_id");

        if (objectId != null) {
            String id = objectId.toHexString();

            complaintId = "CMP-" +
                    id.substring(id.length() - 6)
                     .toUpperCase();
        } else {
            complaintId = "UNKNOWN";
        }
    }

    String customerId =
            getValue(
                    d,
                    "customerId",
                    "customer_id"
            );

    String vehicleId =
            getValue(
                    d,
                    "vehicleId",
                    "vehicle_id"
            );

    String registration =
            getValue(
                    d,
                    "registrationNo",
                    "registration_no"
            );

    String complaintType =
            getValue(
                    d,
                    "complaintType",
                    "complaint_type",
                    "type"
            );

    String date =
            getValue(
                    d,
                    "date",
                    "complaintDate",
                    "complaint_date",
                    "createdAt"
            );

    String status =
            getValue(
                    d,
                    "status"
            );

    String rating =
            getValue(
                    d,
                    "rating",
                    "feedbackRating"
            );

    model.addRow(
            new Object[]{
                    complaintId,
                    customerId,
                    vehicleId,
                    registration,
                    complaintType,
                    date,
                    status,
                    rating
            }
    );
}

    // =========================================================
    // SEARCH
    // =========================================================

    private void searchRecords(
            String keyword
    ) {

        keyword =
                keyword == null
                        ? ""
                        : keyword.trim().toLowerCase();

        model.setRowCount(0);

        try {

            for (Document d :
                    collection.find()
                            .sort(
                                    new Document(
                                            "_id",
                                            -1
                                    )
                            )) {

                String searchable =
                        d.toJson().toLowerCase();

                if (
                        keyword.isEmpty()
                        || searchable.contains(keyword)
                ) {

                    addRow(d);
                }
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Search failed:\n"
                    + ex.getMessage(),
                    "MongoDB Search Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =========================================================
    // ADD COMPLAINT
    // =========================================================

    private void addComplaint() {

        JTextField customerId =
                new JTextField();

        JTextField vehicleId =
                new JTextField();

        JTextField registration =
                new JTextField();

        JTextField type =
                new JTextField();

        JTextField date =
                new JTextField(
                        new java.text.SimpleDateFormat(
                                "yyyy-MM-dd"
                        ).format(
                                new java.util.Date()
                        )
                );

        JComboBox<String> status =
                new JComboBox<>(
                        new String[]{
                                "OPEN",
                                "IN_PROGRESS",
                                "RESOLVED",
                                "CLOSED"
                        }
                );

        JTextField rating =
                new JTextField();

        JTextArea description =
        new JTextArea(5, 25);

description.setLineWrap(true);
description.setWrapStyleWord(true);
description.setFont(
        new Font("Segoe UI", Font.PLAIN, 14)
);

        JPanel panel =
                new JPanel(
                        new GridLayout(
                                0,
                                2,
                                8,
                                8
                        )
                );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        10,
                        10,
                        10,
                        10
                )
        );

        panel.add(
                new JLabel("Customer ID:")
        );
        panel.add(customerId);

        panel.add(
                new JLabel("Vehicle ID:")
        );
        panel.add(vehicleId);

        panel.add(
                new JLabel("Registration No:")
        );
        panel.add(registration);

        panel.add(
                new JLabel("Complaint Type:")
        );
        panel.add(type);

        panel.add(
                new JLabel("Date:")
        );
        panel.add(date);

        panel.add(
                new JLabel("Status:")
        );
        panel.add(status);

        panel.add(
                new JLabel("Rating:")
        );
        panel.add(rating);

        panel.add(
                new JLabel("Description:")
        );

        panel.add(
                new JScrollPane(description)
        );
panel.setPreferredSize(
        new Dimension(500, 500)
);
        int result =
                JOptionPane.showConfirmDialog(
                        this,
                        panel,
                        "Add Complaint / Feedback",
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.PLAIN_MESSAGE
                );

        if (result !=
                JOptionPane.OK_OPTION) {
            return;
        }

        try {

            Document d =
                    new Document();

            d.append(
                    "complaintId",
                    "CMP-"
                    + System.currentTimeMillis()
            );

            d.append(
                    "customerId",
                    customerId.getText().trim()
            );

            d.append(
                    "vehicleId",
                    vehicleId.getText().trim()
            );

            d.append(
                    "registrationNo",
                    registration.getText().trim()
            );

            d.append(
                    "complaintType",
                    type.getText().trim()
            );

            d.append(
                    "date",
                    date.getText().trim()
            );

            d.append(
                    "status",
                    status.getSelectedItem()
                            .toString()
            );

            d.append(
                    "rating",
                    rating.getText().trim()
            );

            d.append(
                    "description",
                    description.getText().trim()
            );

            d.append(
                    "createdAt",
                    new java.text.SimpleDateFormat(
                            "yyyy-MM-dd HH:mm:ss"
                    ).format(
                            new java.util.Date()
                    )
            );

            collection.insertOne(d);

            loadRecords();

            JOptionPane.showMessageDialog(
                    this,
                    "Complaint / feedback added successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to add complaint:\n"
                    + ex.getMessage(),
                    "MongoDB Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =========================================================
    // VIEW SELECTED
    // =========================================================

    private void viewSelected() {

        int row =
                table.getSelectedRow();

        if (row < 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a complaint first.",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int modelRow =
                table.convertRowIndexToModel(
                        row
                );

        String complaintId =
                String.valueOf(
                        model.getValueAt(
                                modelRow,
                                0
                        )
                );

        Document record =
                findRecord(complaintId);

        if (record == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Complaint record not found.",
                    "Not Found",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        showDetails(record);
    }

    // =========================================================
    // FIND RECORD
    // =========================================================

    private Document findRecord(String complaintId) {

    for (Document d : collection.find()) {

        // 1. Check stored complaintId
        String storedId = getValue(
                d,
                "complaintId",
                "complaint_id"
        );

        if (!storedId.isEmpty()
                && storedId.equalsIgnoreCase(complaintId)) {
            return d;
        }

        // 2. Check generated ID from MongoDB _id
        ObjectId objectId = d.getObjectId("_id");

        if (objectId != null) {

            String hexId = objectId.toHexString();

            String generatedId =
                    "CMP-" +
                    hexId.substring(
                            hexId.length() - 6
                    ).toUpperCase();

            if (generatedId.equalsIgnoreCase(complaintId)) {
                return d;
            }
        }
    }

    return null;
}

    // =========================================================
    // VIEW DETAILS
    // =========================================================

    private void showDetails(
            Document d
    ) {

        JTextArea area =
                new JTextArea();

        area.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );

        area.setEditable(false);

        area.setLineWrap(true);
        area.setWrapStyleWord(true);

        area.setBackground(Color.WHITE);

        StringBuilder text =
                new StringBuilder();

        text.append(
                "COMPLAINT & FEEDBACK DETAILS\n"
        );

        text.append(
                "========================================\n\n"
        );

        text.append(
                "Complaint ID     : "
                + getValue(
                        d,
                        "complaintId",
                        "complaint_id"
                )
                + "\n"
        );

        text.append(
                "Customer ID      : "
                + getValue(
                        d,
                        "customerId",
                        "customer_id"
                )
                + "\n"
        );

        text.append(
                "Vehicle ID       : "
                + getValue(
                        d,
                        "vehicleId",
                        "vehicle_id"
                )
                + "\n"
        );

        text.append(
                "Registration No  : "
                + getValue(
                        d,
                        "registrationNo",
                        "registration_no"
                )
                + "\n"
        );

        text.append(
                "Complaint Type   : "
                + getValue(
                        d,
                        "complaintType",
                        "complaint_type",
                        "type"
                )
                + "\n"
        );

        text.append(
                "Date             : "
                + getValue(
                        d,
                        "date",
                        "complaintDate",
                        "complaint_date"
                )
                + "\n"
        );

        text.append(
                "Status           : "
                + getValue(
                        d,
                        "status"
                )
                + "\n"
        );

        text.append(
                "Rating           : "
                + getValue(
                        d,
                        "rating",
                        "feedbackRating"
                )
                + "\n\n"
        );

        text.append(
                "DESCRIPTION\n"
        );

        text.append(
                "----------------------------------------\n"
        );

        text.append(
                getValue(
                        d,
                        "description",
                        "complaint",
                        "feedback"
                )
        );

        text.append(
                "\n\nRESOLUTION\n"
        );

        text.append(
                "----------------------------------------\n"
        );

        text.append(
                getValue(
                        d,
                        "resolution",
                        "resolutionDetails"
                )
        );
        area.setText(text.toString());

        JScrollPane scroll =
                new JScrollPane(area);

        scroll.setPreferredSize(
                new Dimension(
                        650,
                        500
                )
        );

        JOptionPane.showMessageDialog(
                this,
                scroll,
                "Complaint Details",
                JOptionPane.PLAIN_MESSAGE
        );
    }

    // =========================================================
    // DELETE
    // =========================================================

    private void deleteSelected() {

        int row =
                table.getSelectedRow();

        if (row < 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a complaint first.",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int modelRow =
                table.convertRowIndexToModel(
                        row
                );

        String complaintId =
                String.valueOf(
                        model.getValueAt(
                                modelRow,
                                0
                        )
                );

        
        int confirm =
                JOptionPane.showConfirmDialog(
                        this,
                        "Delete complaint "
                        + complaintId
                        + "?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

        if (confirm !=
                JOptionPane.YES_OPTION) {
            return;
        }

        try {

            Document record =
                    findRecord(complaintId);

            if (record != null
                    && record.getObjectId("_id")
                    != null) {

                ObjectId id =
                        record.getObjectId("_id");

                collection.deleteOne(
                        Filters.eq(
                                "_id",
                                id
                        )
                );

            } else {

                collection.deleteOne(
                        Filters.eq(
                                "complaintId",
                                complaintId
                        )
                );
            }

            loadRecords();

            JOptionPane.showMessageDialog(
                    this,
                    "Complaint deleted successfully.",
                    "Deleted",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to delete complaint:\n"
                    + ex.getMessage(),
                    "MongoDB Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =========================================================
    // GET VALUE
    // =========================================================

    private String getValue(
            Document d,
            String... keys
    ) {

        for (String key : keys) {

            Object value =
                    d.get(key);

            if (value != null) {

                if (value instanceof Document) {

                    Document nested =
                            (Document) value;

                    if (nested.containsKey("name")) {
                        return String.valueOf(
                                nested.get("name")
                        );
                    }
                }

                return String.valueOf(value);
            }
        }

        return "";
    }
}