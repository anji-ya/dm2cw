package com.vehicle.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class OracleConnection {
    private OracleConnection() {}

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                DBConfig.ORACLE_URL,
                DBConfig.ORACLE_USER,
                DBConfig.ORACLE_PASSWORD
        );
    }

    public static boolean testConnection() {
        try (Connection c = getConnection()) {
            return c != null && !c.isClosed();
        } catch (SQLException ex) {
            return false;
        }
    }
}
