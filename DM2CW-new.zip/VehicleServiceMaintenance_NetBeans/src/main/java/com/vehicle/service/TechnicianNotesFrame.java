
package com.vehicle.service;


import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import javax.swing.JTextField;




import org.bson.types.ObjectId;


public class TechnicianNotesFrame extends JFrame {

    private final MongoCollection<org.bson.Document> collection;

    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    public TechnicianNotesFrame() {

        MongoDatabase db = MongoConnection.getDatabase();
        collection = db.getCollection("service_records");

        setTitle("Technician Service Notes");
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        buildUI();
        loadRecords();
    }

    // =========================================================
    // MAIN UI
    // =========================================================

    private void buildUI() {

        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBackground(new Color(245, 247, 250));
        main.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // -----------------------------------------------------
        // HEADER
        // -----------------------------------------------------

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(210, 214, 220)),
                        BorderFactory.createEmptyBorder(15, 20, 15, 20)
                )
        );

       JLabel subtitle = new JLabel("Technician Service Notes & Job Records");
subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
subtitle.setForeground(new Color(107, 114, 128));

JPanel heading = new JPanel(new GridLayout(1, 1));
heading.setOpaque(false);
heading.add(subtitle);

header.add(heading, BorderLayout.WEST);

        // -----------------------------------------------------
        // BUTTONS
        // -----------------------------------------------------

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);

        searchField = new JTextField(15);

JButton searchButton = new JButton("Search");
JButton view = new JButton("View Service Notes");
JButton export = new JButton("Export PDF");
JButton print = new JButton("Print");
JButton close = new JButton("Close");

styleButton(searchButton);
styleButton(view);
styleButton(export);
styleButton(print);
styleButton(close);

searchButton.addActionListener(e ->
        searchRecords(searchField.getText().trim())
);

view.addActionListener(e -> viewSelectedRecord());
export.addActionListener(e -> exportSelectedPDF());
print.addActionListener(e -> printSelected());
close.addActionListener(e -> dispose());

buttons.add(searchField);
buttons.add(searchButton);
buttons.add(view);
buttons.add(export);
buttons.add(print);
buttons.add(close);
        header.add(buttons, BorderLayout.EAST);

        // -----------------------------------------------------
        // TABLE
        // -----------------------------------------------------

        String[] columns = {
            "Job Card",
            "Vehicle ID",
            "Registration",
            "Customer ID",
            "Service Date",
            "Service Type",
            "Technician",
            "Status",
            "Mileage"
        };

        tableModel = new DefaultTableModel(columns, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowHeight(32);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 13)
        );
        table.getTableHeader().setBackground(
                new Color(226, 232, 240)
        );
        table.getTableHeader().setForeground(
                new Color(31, 41, 55)
        );

        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        table.addMouseListener(new java.awt.event.MouseAdapter() {

            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {

                if (e.getClickCount() == 2) {
                    viewSelectedRecord();
                }
            }
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(
                BorderFactory.createLineBorder(
                        new Color(210, 214, 220)
                )
        );

        // -----------------------------------------------------
        // FOOTER
        // -----------------------------------------------------

        JLabel footer = new JLabel(
                "Select a service record and choose \"View Service Notes\" to open the full document."
        );

        footer.setFont(
                new Font("Segoe UI", Font.PLAIN, 12)
        );

        footer.setForeground(
                new Color(107, 114, 128)
        );

        footer.setBorder(
                BorderFactory.createEmptyBorder(5, 5, 0, 5)
        );

        main.add(header, BorderLayout.NORTH);
        main.add(scroll, BorderLayout.CENTER);
        main.add(footer, BorderLayout.SOUTH);

        add(main);
    }

    // =========================================================
    // LOAD MONGODB RECORDS
    // =========================================================

    private void searchRecords(String keyword) {

    tableModel.setRowCount(0);

    try {

        String search = keyword == null ? "" : keyword.trim();

        if (search.isEmpty()) {
            loadRecords();
            return;
        }

        String regex = ".*" + java.util.regex.Pattern.quote(search) + ".*";

        org.bson.Document query =
                new org.bson.Document("$or", java.util.Arrays.asList(

                        new org.bson.Document(
                                "jobCardNo",
                                new org.bson.Document("$regex", regex)
                        ),

                        new org.bson.Document(
                                "registrationNo",
                                new org.bson.Document("$regex", regex)
                        ),

                        new org.bson.Document(
                                "serviceDate",
                                new org.bson.Document("$regex", regex)
                        ),

                        new org.bson.Document(
                                "serviceType",
                                new org.bson.Document("$regex", regex)
                        ),

                        new org.bson.Document(
                                "status",
                                new org.bson.Document("$regex", regex)
                        ),

                        new org.bson.Document(
                                "vehicleId",
                                new org.bson.Document("$regex", regex)
                        ),

                        new org.bson.Document(
                                "customerId",
                                new org.bson.Document("$regex", regex)
                        ),

                        new org.bson.Document(
                                "mileage",
                                new org.bson.Document("$regex", regex)
                        )
                ));

        for (org.bson.Document d :
                collection.find(query)
                        .sort(new org.bson.Document("serviceDate", -1))) {

            String jobCard = safe(d.get("jobCardNo"));
            String vehicleId = safe(d.get("vehicleId"));
            String registration = safe(d.get("registrationNo"));
            String customerId = safe(d.get("customerId"));
            String serviceDate = safe(d.get("serviceDate"));
            String serviceType = safe(d.get("serviceType"));
            String technician = getTechnicianName(d);
            String status = safe(d.get("status"));
            String mileage = safe(d.get("mileage"));

            tableModel.addRow(new Object[]{
                jobCard,
                vehicleId,
                registration,
                customerId,
                serviceDate,
                serviceType,
                technician,
                status,
                mileage
            });
        }

    } catch (Exception ex) {

        JOptionPane.showMessageDialog(
                this,
                "Search failed:\n" + ex.getMessage(),
                "MongoDB Search Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
    // =========================================================
// LOAD MONGODB RECORDS
// =========================================================

private void loadRecords() {

    tableModel.setRowCount(0);

    try {

        for (org.bson.Document d :
                collection.find().sort(
                        new org.bson.Document("serviceDate", -1)
                )) {

            String jobCard =
                    safe(d.get("jobCardNo"));

            String vehicleId =
                    safe(d.get("vehicleId"));

            String registration =
                    safe(d.get("registrationNo"));

            String customerId =
                    safe(d.get("customerId"));

            String serviceDate =
                    safe(d.get("serviceDate"));

            String serviceType =
                    safe(d.get("serviceType"));

            String technician =
                    getTechnicianName(d);

            String status =
                    safe(d.get("status"));

            String mileage =
                    safe(d.get("mileage"));

            tableModel.addRow(
                    new Object[]{
                            jobCard,
                            vehicleId,
                            registration,
                            customerId,
                            serviceDate,
                            serviceType,
                            technician,
                            status,
                            mileage
                    }
            );
        }

    } catch (Exception ex) {

        JOptionPane.showMessageDialog(
                this,
                "Unable to load service records:\n"
                        + ex.getMessage(),
                "MongoDB Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

    // =========================================================
    // VIEW SELECTED RECORD
    // =========================================================

    private void viewSelectedRecord() {

        int row = table.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a service record first.",
                    "No Record Selected",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        String jobCard =
                String.valueOf(
                        tableModel.getValueAt(row, 0)
                );

        org.bson.Document record =
                collection.find(
                        Filters.eq("jobCardNo", jobCard)
                ).first();

        if (record == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Service record could not be found.",
                    "Record Not Found",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        new TechnicianServiceDocumentFrame(record)
                .setVisible(true);
    }

    // =========================================================
    // EXPORT PDF
    // =========================================================

    private void exportSelectedPDF() {

        int row = table.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a service record first.",
                    "No Record Selected",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        String jobCard =
                String.valueOf(
                        tableModel.getValueAt(row, 0)
                );

        org.bson.Document record =
                collection.find(
                        Filters.eq("jobCardNo", jobCard)
                ).first();

        if (record == null) {
            return;
        }

        try {

            javax.swing.JFileChooser chooser =
                    new javax.swing.JFileChooser();

            chooser.setSelectedFile(
                    new java.io.File(
                            jobCard + "_Technician_Notes.pdf"
                    )
            );

            if (chooser.showSaveDialog(this)
                    != javax.swing.JFileChooser.APPROVE_OPTION) {
                return;
            }

            java.io.File file =
                    chooser.getSelectedFile();

            createPDF(record, file);

            JOptionPane.showMessageDialog(
                    this,
                    "PDF exported successfully.\n\n"
                    + file.getAbsolutePath(),
                    "Export Complete",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to export PDF:\n"
                    + ex.getMessage(),
                    "PDF Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =========================================================
    // CREATE PDF
    // =========================================================

    private void createPDF(
            org.bson.Document d,
            java.io.File file
    ) throws Exception {

        com.lowagie.text.Document pdf =
                new com.lowagie.text.Document(
                        com.lowagie.text.PageSize.A4,
                        40,
                        40,
                        40,
                        40
                );

        com.lowagie.text.pdf.PdfWriter.getInstance(
                pdf,
                new FileOutputStream(file)
        );

        pdf.open();

        com.lowagie.text.Font titleFont =
                new com.lowagie.text.Font(
                        com.lowagie.text.Font.HELVETICA,
                        20,
                        com.lowagie.text.Font.BOLD
                );

        com.lowagie.text.Font headingFont =
                new com.lowagie.text.Font(
                        com.lowagie.text.Font.HELVETICA,
                        12,
                        com.lowagie.text.Font.BOLD
                );

        com.lowagie.text.Font normalFont =
                new com.lowagie.text.Font(
                        com.lowagie.text.Font.HELVETICA,
                        10
                );

        com.lowagie.text.Paragraph title =
                new com.lowagie.text.Paragraph(
                        "VSM SERVICE NETWORK",
                        titleFont
                );

        title.setAlignment(
                com.lowagie.text.Element.ALIGN_CENTER
        );

        pdf.add(title);

        com.lowagie.text.Paragraph sub =
                new com.lowagie.text.Paragraph(
                        "TECHNICIAN SERVICE NOTES",
                        headingFont
                );

        sub.setAlignment(
                com.lowagie.text.Element.ALIGN_CENTER
        );

        pdf.add(sub);

        pdf.add(
                new com.lowagie.text.Paragraph(
                        " ",
                        normalFont
                )
        );

        addPDFHeading(pdf, "JOB CARD INFORMATION");

        addPDFLine(
                pdf,
                "Job Card",
                safe(d.get("jobCardNo"))
        );

        addPDFLine(
                pdf,
                "Service Date",
                safe(d.get("serviceDate"))
        );

        addPDFLine(
                pdf,
                "Service Type",
                safe(d.get("serviceType"))
        );

        addPDFLine(
                pdf,
                "Status",
                safe(d.get("status"))
        );

        addPDFHeading(pdf, "VEHICLE INFORMATION");

        addPDFLine(
                pdf,
                "Vehicle ID",
                safe(d.get("vehicleId"))
        );

        addPDFLine(
                pdf,
                "Registration",
                safe(d.get("registrationNo"))
        );

        addPDFLine(
                pdf,
                "Customer ID",
                safe(d.get("customerId"))
        );

        addPDFLine(
                pdf,
                "Mileage",
                safe(d.get("mileage")) + " km"
        );

        addPDFHeading(pdf, "TECHNICIAN INFORMATION");

        addPDFLine(
                pdf,
                "Technician",
                getTechnicianName(d)
        );

        addPDFHeading(pdf, "TECHNICIAN NOTES");

        Object notesObj =
                d.get("technicianNotes");

        if (notesObj instanceof List<?>) {

            for (Object note :
                    (List<?>) notesObj) {

                pdf.add(
                        new com.lowagie.text.Paragraph(
                                "• " + safe(note),
                                normalFont
                        )
                );
            }

        } else {

            pdf.add(
                    new com.lowagie.text.Paragraph(
                            "No technician notes recorded.",
                            normalFont
                    )
            );
        }

        addPDFHeading(pdf, "PARTS USED");

        Object partsObj =
                d.get("partsUsed");

        if (partsObj instanceof List<?>) {

            for (Object part :
                    (List<?>) partsObj) {

                pdf.add(
                        new com.lowagie.text.Paragraph(
                                "• " + safe(part),
                                normalFont
                        )
                );
            }

        } else {

            pdf.add(
                    new com.lowagie.text.Paragraph(
                            "No parts recorded.",
                            normalFont
                    )
            );
        }

        addPDFHeading(pdf, "SERVICE HISTORY");

        Object historyObj =
                d.get("serviceHistory");

        if (historyObj instanceof org.bson.Document) {

            org.bson.Document history =
                    (org.bson.Document) historyObj;

            addPDFLine(
                    pdf,
                    "Previous Service",
                    safe(history.get("previousService"))
            );

            addPDFLine(
                    pdf,
                    "Service Interval",
                    safe(history.get("serviceInterval"))
            );

            addPDFLine(
                    pdf,
                    "Next Recommendation",
                    safe(history.get("nextServiceRecommendation"))
            );

        } else {

            pdf.add(
                    new com.lowagie.text.Paragraph(
                            "No service history recorded.",
                            normalFont
                    )
            );
        }

        pdf.add(
                new com.lowagie.text.Paragraph(
                        "\n\nTechnician Signature: ______________________________",
                        normalFont
                )
        );

        pdf.add(
                new com.lowagie.text.Paragraph(
                        "\nCustomer Signature: _________________________________",
                        normalFont
                )
        );

        pdf.add(
                new com.lowagie.text.Paragraph(
                        "\n\nVSM SERVICE NETWORK",
                        headingFont
                )
        );

        pdf.close();
    }

    // =========================================================
    // PRINT
    // =========================================================

    private void printSelected() {

        int row = table.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a service record first.",
                    "No Record Selected",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        String jobCard =
                String.valueOf(
                        tableModel.getValueAt(row, 0)
                );

        org.bson.Document record =
                collection.find(
                        Filters.eq("jobCardNo", jobCard)
                ).first();

        if (record == null) {
            return;
        }

        String text =
                createPrintableText(record);

        JTextArea area =
                new JTextArea(text);

        area.setFont(
                new Font(
                        "Monospaced",
                        Font.PLAIN,
                        10
                )
        );

        try {

            PrinterJob job =
                    PrinterJob.getPrinterJob();

            job.setPrintable(area.getPrintable(
                    null,
                    null
            ));

            if (job.printDialog()) {
                job.print();
            }

        } catch (PrinterException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to print:\n"
                    + ex.getMessage(),
                    "Print Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =========================================================
    // PRINTABLE TEXT
    // =========================================================

    private String createPrintableText(
            org.bson.Document d
    ) {

        StringBuilder sb =
                new StringBuilder();

        sb.append(
                "====================================================\n"
        );

        sb.append(
                "                 VSM SERVICE NETWORK\n"
        );

        sb.append(
                "             TECHNICIAN SERVICE NOTES\n"
        );

        sb.append(
                "====================================================\n\n"
        );

        sb.append(
                "JOB CARD INFORMATION\n"
        );

        sb.append(
                "----------------------------------------------------\n"
        );

        sb.append(
                "Job Card      : "
                + safe(d.get("jobCardNo"))
                + "\n"
        );

        sb.append(
                "Service Date  : "
                + safe(d.get("serviceDate"))
                + "\n"
        );

        sb.append(
                "Service Type  : "
                + safe(d.get("serviceType"))
                + "\n"
        );

        sb.append(
                "Status        : "
                + safe(d.get("status"))
                + "\n\n"
        );

        sb.append(
                "VEHICLE INFORMATION\n"
        );

        sb.append(
                "----------------------------------------------------\n"
        );

        sb.append(
                "Vehicle ID    : "
                + safe(d.get("vehicleId"))
                + "\n"
        );

        sb.append(
                "Registration  : "
                + safe(d.get("registrationNo"))
                + "\n"
        );

        sb.append(
                "Customer ID   : "
                + safe(d.get("customerId"))
                + "\n"
        );

        sb.append(
                "Mileage       : "
                + safe(d.get("mileage"))
                + " km\n\n"
        );

        sb.append(
                "TECHNICIAN INFORMATION\n"
        );

        sb.append(
                "----------------------------------------------------\n"
        );

        sb.append(
                "Technician    : "
                + getTechnicianName(d)
                + "\n\n"
        );

        sb.append(
                "TECHNICIAN NOTES\n"
        );

        sb.append(
                "----------------------------------------------------\n"
        );

        Object notes =
                d.get("technicianNotes");

        if (notes instanceof List<?>) {

            for (Object n :
                    (List<?>) notes) {

                sb.append(
                        "• " + safe(n) + "\n"
                );
            }

        } else {

            sb.append(
                    "No technician notes recorded.\n"
            );
        }

        sb.append(
                "\n====================================================\n"
        );

        sb.append(
                "                 VSM SERVICE NETWORK\n"
        );

        sb.append(
                "====================================================\n"
        );

        return sb.toString();
    }

    // =========================================================
    // DOCUMENT DETAIL WINDOW
    // =========================================================

    private static class TechnicianServiceDocumentFrame
            extends JFrame {

        private final org.bson.Document record;

        private JTextArea documentArea;

        TechnicianServiceDocumentFrame(
                org.bson.Document record
        ) {

            this.record = record;

            setTitle("Technician Service Notes - "
                    + safe(record.get("jobCardNo")));

            setSize(850, 700);
            setLocationRelativeTo(null);

            buildDocument();
        }

        private void buildDocument() {

            JPanel main =
                    new JPanel(new BorderLayout());

            main.setBackground(
                    new Color(235, 238, 243)
            );

            JPanel document =
                    new JPanel(new BorderLayout());

            document.setBackground(Color.WHITE);

            document.setBorder(
                    BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(
                                    new Color(190, 195, 200)
                            ),
                            BorderFactory.createEmptyBorder(
                                    25, 35, 25, 35
                            )
                    )
            );

            // -------------------------------------------------
            // HEADER
            // -------------------------------------------------

            JPanel header =
                    new JPanel(new GridLayout(2, 1));

            header.setBackground(Color.WHITE);

            JLabel company =
                    new JLabel(
                            "VSM SERVICE NETWORK",
                            SwingConstants.CENTER
                    );

            company.setFont(
                    new Font(
                            "Segoe UI",
                            Font.BOLD,
                            24
                    )
            );

            company.setForeground(
                    new Color(31, 41, 55)
            );

            JLabel heading =
                    new JLabel(
                            "TECHNICIAN SERVICE NOTES",
                            SwingConstants.CENTER
                    );

            heading.setFont(
                    new Font(
                            "Segoe UI",
                            Font.BOLD,
                            16
                    )
            );

            heading.setForeground(
                    new Color(75, 85, 99)
            );

            header.add(company);
            header.add(heading);

            // -------------------------------------------------
            // CONTENT
            // -------------------------------------------------

            documentArea =
                    new JTextArea();

            documentArea.setText(
                    createDocumentText(record)
            );

            documentArea.setFont(
                    new Font(
                            "Segoe UI",
                            Font.PLAIN,
                            14
                    )
            );

            documentArea.setForeground(
                    new Color(31, 41, 55)
            );

            documentArea.setBackground(Color.WHITE);

            documentArea.setEditable(false);

            documentArea.setLineWrap(true);
            documentArea.setWrapStyleWord(true);

            documentArea.setMargin(
                    new Insets(15, 5, 15, 5)
            );

            JScrollPane scroll =
                    new JScrollPane(documentArea);

            scroll.setBorder(null);

            document.add(header, BorderLayout.NORTH);
            document.add(scroll, BorderLayout.CENTER);

            // -------------------------------------------------
            // BUTTONS
            // -------------------------------------------------

            JPanel bottom =
                    new JPanel(
                            new FlowLayout(
                                    FlowLayout.RIGHT,
                                    10,
                                    10
                            )
                    );

            bottom.setBackground(Color.WHITE);

            JButton export =
                    new JButton("Export PDF");

            JButton print =
                    new JButton("Print");

            JButton close =
                    new JButton("Close");

            export.addActionListener(
                    e -> exportPDF()
            );

            print.addActionListener(
                    e -> printDocument()
            );

            close.addActionListener(
                    e -> dispose()
            );

            bottom.add(export);
            bottom.add(print);
            bottom.add(close);

            main.setBorder(
                    BorderFactory.createEmptyBorder(
                            15, 15, 15, 15
                    )
            );

            main.add(document, BorderLayout.CENTER);
            main.add(bottom, BorderLayout.SOUTH);

            add(main);
        }

        // -----------------------------------------------------
        // DOCUMENT TEXT
        // -----------------------------------------------------

        private String createDocumentText(
                org.bson.Document d
        ) {

            StringBuilder sb =
                    new StringBuilder();

            sb.append(
                    "\nJOB CARD INFORMATION\n"
            );

            sb.append(
                    "──────────────────────────────────────────────\n"
            );

            sb.append(
                    String.format(
                            "%-20s : %s%n",
                            "Job Card",
                            safe(d.get("jobCardNo"))
                    )
            );

            sb.append(
                    String.format(
                            "%-20s : %s%n",
                            "Service Date",
                            safe(d.get("serviceDate"))
                    )
            );

            sb.append(
                    String.format(
                            "%-20s : %s%n",
                            "Service Type",
                            safe(d.get("serviceType"))
                    )
            );

            sb.append(
                    String.format(
                            "%-20s : %s%n",
                            "Status",
                            safe(d.get("status"))
                    )
            );

            sb.append("\n");

            sb.append(
                    "VEHICLE INFORMATION\n"
            );

            sb.append(
                    "──────────────────────────────────────────────\n"
            );

            sb.append(
                    String.format(
                            "%-20s : %s%n",
                            "Vehicle ID",
                            safe(d.get("vehicleId"))
                    )
            );

            sb.append(
                    String.format(
                            "%-20s : %s%n",
                            "Registration",
                            safe(d.get("registrationNo"))
                    )
            );

            sb.append(
                    String.format(
                            "%-20s : %s%n",
                            "Customer ID",
                            safe(d.get("customerId"))
                    )
            );

            sb.append(
                    String.format(
                            "%-20s : %s km%n",
                            "Mileage",
                            safe(d.get("mileage"))
                    )
            );

            sb.append("\n");

            sb.append(
                    "TECHNICIAN INFORMATION\n"
            );

            sb.append(
                    "──────────────────────────────────────────────\n"
            );

            sb.append(
                    String.format(
                            "%-20s : %s%n",
                            "Technician",
                            getTechnicianName(d)
                    )
            );

            sb.append("\n");

            sb.append(
                    "TECHNICIAN NOTES\n"
            );

            sb.append(
                    "──────────────────────────────────────────────\n"
            );

            Object notes =
                    d.get("technicianNotes");

            if (notes instanceof List<?>) {

                for (Object note :
                        (List<?>) notes) {

                    sb.append(
                            "  • " + safe(note) + "\n"
                    );
                }

            } else {

                sb.append(
                        "  No technician notes recorded.\n"
                );
            }

            sb.append("\n");

            sb.append(
                    "PARTS USED\n"
            );

            sb.append(
                    "──────────────────────────────────────────────\n"
            );

            Object parts =
                    d.get("partsUsed");

            if (parts instanceof List<?>) {

                for (Object part :
                        (List<?>) parts) {

                    sb.append(
                            "  • " + safe(part) + "\n"
                    );
                }

            } else {

                sb.append(
                        "  No parts recorded.\n"
                );
            }

            sb.append("\n");

            sb.append(
                    "SERVICE HISTORY\n"
            );

            sb.append(
                    "──────────────────────────────────────────────\n"
            );

            Object historyObj =
                    d.get("serviceHistory");

            if (historyObj
                    instanceof org.bson.Document) {

                org.bson.Document history =
                        (org.bson.Document) historyObj;

                sb.append(
                        String.format(
                                "%-25s : %s%n",
                                "Previous Service",
                                safe(
                                        history.get(
                                                "previousService"
                                        )
                                )
                        )
                );

                sb.append(
                        String.format(
                                "%-25s : %s%n",
                                "Service Interval",
                                safe(
                                        history.get(
                                                "serviceInterval"
                                        )
                                )
                        )
                );

               sb.append(
        String.format(
                "%-25s : %s%n",
                "Next Recommendation",
                safe(
                        history.get(
                                "nextServiceRecommendation"
                        )
                )
        )
);

            } else {

                sb.append(
                        "  No service history recorded.\n"
                );
            }

            sb.append("\n\n");

            sb.append(
                    "Technician Signature: "
                    + "________________________________\n\n"
            );

            sb.append(
                    "Customer Signature:   "
                    + "________________________________\n\n"
            );

            sb.append(
                    "──────────────────────────────────────────────\n"
            );

            sb.append(
                    "              VSM SERVICE NETWORK\n"
            );

            sb.append(
                    "──────────────────────────────────────────────\n"
            );

            return sb.toString();
        }

        // -----------------------------------------------------
        // PDF FROM DETAIL WINDOW
        // -----------------------------------------------------

        private void exportPDF() {

            try {

                javax.swing.JFileChooser chooser =
                        new javax.swing.JFileChooser();

                chooser.setSelectedFile(
                        new java.io.File(
                                safe(record.get("jobCardNo"))
                                + "_Service_Notes.pdf"
                        )
                );

                if (chooser.showSaveDialog(this)
                        != javax.swing.JFileChooser.APPROVE_OPTION) {

                    return;
                }

                java.io.File file =
                        chooser.getSelectedFile();

                com.lowagie.text.Document pdf =
                        new com.lowagie.text.Document(
                                com.lowagie.text.PageSize.A4,
                                45,
                                45,
                                45,
                                45
                        );

                com.lowagie.text.pdf.PdfWriter
                        .getInstance(
                                pdf,
                                new FileOutputStream(file)
                        );

                pdf.open();

                com.lowagie.text.Font title =
                        new com.lowagie.text.Font(
                                com.lowagie.text.Font.HELVETICA,
                                20,
                                com.lowagie.text.Font.BOLD
                        );

                com.lowagie.text.Font heading =
                        new com.lowagie.text.Font(
                                com.lowagie.text.Font.HELVETICA,
                                12,
                                com.lowagie.text.Font.BOLD
                        );

                com.lowagie.text.Font body =
                        new com.lowagie.text.Font(
                                com.lowagie.text.Font.HELVETICA,
                                10
                        );

                com.lowagie.text.Paragraph p =
                        new com.lowagie.text.Paragraph(
                                "VSM SERVICE NETWORK",
                                title
                        );

                p.setAlignment(
                        com.lowagie.text.Element.ALIGN_CENTER
                );

                pdf.add(p);

                p =
                        new com.lowagie.text.Paragraph(
                                "TECHNICIAN SERVICE NOTES",
                                heading
                        );

                p.setAlignment(
                        com.lowagie.text.Element.ALIGN_CENTER
                );

                pdf.add(p);

                pdf.add(
                        new com.lowagie.text.Paragraph(
                                "Job Card: "
                                + safe(
                                        record.get(
                                                "jobCardNo"
                                        )
                                ),
                                body
                        )
                );

                pdf.add(
                        new com.lowagie.text.Paragraph(
                                "Service Date: "
                                + safe(
                                        record.get(
                                                "serviceDate"
                                        )
                                ),
                                body
                        )
                );

                addPDFHeading(
                        pdf,
                        "VEHICLE INFORMATION"
                );

                addPDFLine(
                        pdf,
                        "Vehicle ID",
                        safe(record.get("vehicleId"))
                );

                addPDFLine(
                        pdf,
                        "Registration",
                        safe(record.get("registrationNo"))
                );

                addPDFLine(
                        pdf,
                        "Customer ID",
                        safe(record.get("customerId"))
                );

                addPDFLine(
                        pdf,
                        "Mileage",
                        safe(record.get("mileage"))
                                + " km"
                );

                addPDFHeading(
                        pdf,
                        "TECHNICIAN INFORMATION"
                );

                addPDFLine(
                        pdf,
                        "Technician",
                        getTechnicianName(record)
                );

                addPDFHeading(
                        pdf,
                        "TECHNICIAN NOTES"
                );

                Object notes =
                        record.get(
                                "technicianNotes"
                        );

                if (notes instanceof List<?>) {

                    for (Object note :
                            (List<?>) notes) {

                        pdf.add(
                                new com.lowagie.text.Paragraph(
                                        "• " + safe(note),
                                        body
                                )
                        );
                    }

                } else {

                    pdf.add(
                            new com.lowagie.text.Paragraph(
                                    "No technician notes recorded.",
                                    body
                            )
                    );
                }

                addPDFHeading(
                        pdf,
                        "PARTS USED"
                );

                Object parts =
                        record.get(
                                "partsUsed"
                        );

                if (parts instanceof List<?>) {

                    for (Object part :
                            (List<?>) parts) {

                        pdf.add(
                                new com.lowagie.text.Paragraph(
                                        "• " + safe(part),
                                        body
                                )
                        );
                    }

                } else {

                    pdf.add(
                            new com.lowagie.text.Paragraph(
                                    "No parts recorded.",
                                    body
                            )
                    );
                }

                addPDFHeading(
                        pdf,
                        "SERVICE HISTORY"
                );

                Object historyObj =
                        record.get(
                                "serviceHistory"
                        );

                if (historyObj
                        instanceof org.bson.Document) {

                    org.bson.Document history =
                            (org.bson.Document)
                                    historyObj;

                    addPDFLine(
                            pdf,
                            "Previous Service",
                            safe(
                                    history.get(
                                            "previousService"
                                    )
                            )
                    );

                    addPDFLine(
                            pdf,
                            "Service Interval",
                            safe(
                                    history.get(
                                            "serviceInterval"
                                    )
                            )
                    );

                    addPDFLine(
                            pdf,
                            "Next Recommendation",
                            safe(
                                    history.get(
                                            "nextServiceRecommendation"
                                    )
                            )
                    );
                }

                pdf.add(
                        new com.lowagie.text.Paragraph(
                                "\n\nTechnician Signature: "
                                + "____________________________",
                                body
                        )
                );

                pdf.add(
                        new com.lowagie.text.Paragraph(
                                "\nCustomer Signature: "
                                + "____________________________",
                                body
                        )
                );

                pdf.close();

                JOptionPane.showMessageDialog(
                        this,
                        "PDF exported successfully.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        "Unable to export PDF:\n"
                        + ex.getMessage(),
                        "PDF Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }

        // -----------------------------------------------------
        // PRINT
        // -----------------------------------------------------

        private void printDocument() {

            try {

                PrinterJob job =
                        PrinterJob.getPrinterJob();

                job.setPrintable(
                        documentArea.getPrintable(
                                null,
                                null
                        )
                );

                if (job.printDialog()) {
                    job.print();
                }

            } catch (PrinterException ex) {

                JOptionPane.showMessageDialog(
                        this,
                        "Unable to print:\n"
                        + ex.getMessage(),
                        "Print Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }

    // =========================================================
    // HELPERS
    // =========================================================

    private static String safe(Object value) {

        if (value == null) {
            return "";
        }

        return String.valueOf(value);
    }

    private static String getTechnicianName(
            org.bson.Document d
    ) {

        Object technician =
                d.get("technician");

        if (technician
                instanceof org.bson.Document) {

            org.bson.Document tech =
                    (org.bson.Document) technician;

            return safe(
                    tech.get("name")
            );
        }

        return safe(technician);
    }

    private void styleButton(JButton button) {

        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        12
                )
        );

        button.setFocusPainted(false);

        button.setPreferredSize(
                new Dimension(130, 34)
        );
    }

    private static void addPDFHeading(
            com.lowagie.text.Document pdf,
            String text
    ) throws Exception {

        com.lowagie.text.Font font =
                new com.lowagie.text.Font(
                        com.lowagie.text.Font.HELVETICA,
                        12,
                        com.lowagie.text.Font.BOLD
                );

        pdf.add(
                new com.lowagie.text.Paragraph(
                        "\n" + text,
                        font
                )
        );
    }

    private static void addPDFLine(
            com.lowagie.text.Document pdf,
            String label,
            String value
    ) throws Exception {

        com.lowagie.text.Font font =
                new com.lowagie.text.Font(
                        com.lowagie.text.Font.HELVETICA,
                        10
                );

        pdf.add(
                new com.lowagie.text.Paragraph(
                        label + " : " + value,
                        font
                )
        );
    }
}