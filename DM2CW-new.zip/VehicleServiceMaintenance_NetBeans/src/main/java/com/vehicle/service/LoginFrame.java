package com.vehicle.service;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class LoginFrame extends JFrame {
    private final JTextField username = new JTextField("admin");
    private final JPasswordField password = new JPasswordField("admin123");

    public LoginFrame() {
        setTitle("Vehicle Service & Maintenance Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(480, 430);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(AppTheme.LIGHT);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(AppTheme.NAVY);
        header.setBorder(new EmptyBorder(28, 30, 28, 30));
        JLabel h = new JLabel("<html><b>VEHICLE SERVICE</b><br/>Management System</html>");
        h.setForeground(AppTheme.TEXT);
        h.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        header.add(h, BorderLayout.WEST);

        JPanel form = AppTheme.card();
        form.setBorder(new EmptyBorder(28, 36, 28, 36));

        JLabel welcome = new JLabel("Staff Login");
        welcome.setFont(new Font("Segoe UI", Font.BOLD, 20));
        welcome.setForeground(AppTheme.TEXT);

        JPanel fields = new JPanel(new GridLayout(4, 1, 8, 8));
        fields.setOpaque(false);
        fields.add(new JLabel("Username"));
        fields.add(username);
        fields.add(new JLabel("Password"));
        fields.add(password);

        JButton login = AppTheme.button("Sign In");
        login.addActionListener(e -> login());

        JButton test = new JButton("Test database connections");
        test.addActionListener(e -> testConnections());

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.setOpaque(false);
        bottom.add(test);
        bottom.add(login);

        form.add(welcome, BorderLayout.NORTH);
        form.add(fields, BorderLayout.CENTER);
        form.add(bottom, BorderLayout.SOUTH);

        root.add(header, BorderLayout.NORTH);
        root.add(form, BorderLayout.CENTER);
        add(root);

        getRootPane().setDefaultButton(login);
    }

    private void login() {
        String user = username.getText().trim();
        String pass = new String(password.getPassword());

        if (user.equals("admin") && pass.equals("admin123")) {
            new DashboardFrame().setVisible(true);
            dispose();
            return;
        }

        String sql = "SELECT username FROM VSM_USERS WHERE username=? AND password_hash=? AND active='Y'";
        try (Connection c = OracleConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, user);
            ps.setString(2, PasswordUtil.sha256(pass));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    new DashboardFrame().setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid username or password.");
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Oracle login unavailable.\nDefault demo login: admin / admin123\n\n" + ex.getMessage(),
                    "Login", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void testConnections() {
        boolean oracle = OracleConnection.testConnection();
        boolean mongo = MongoConnection.testConnection();
        JOptionPane.showMessageDialog(this,
                "Oracle: " + (oracle ? "CONNECTED" : "NOT CONNECTED") +
                "\nMongoDB: " + (mongo ? "CONNECTED" : "NOT CONNECTED"),
                "Connection Test", oracle && mongo ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.WARNING_MESSAGE);
    }
}
