package com.vehicle.service;

/**
 * Central configuration for both databases.
 * Change only this class when Oracle/MongoDB credentials differ.
 */
public final class DBConfig {
    private DBConfig() {}

    // Oracle Free / Oracle XE examples:
    // jdbc:oracle:thin:@localhost:1521/FREEPDB1
    // jdbc:oracle:thin:@localhost:1521/XEPDB1
    public static final String ORACLE_URL =
    "jdbc:oracle:thin:@localhost:1521/orclpdb";
    public static final String ORACLE_USER =
            System.getenv().getOrDefault("VSM_ORACLE_USER", "VSM_APP");
    public static final String ORACLE_PASSWORD =
            System.getenv().getOrDefault("VSM_ORACLE_PASSWORD", "VSM_APP");

    // MongoDB local server.
    // For a local installation without authentication, this is enough.
    public static final String MONGO_URI =
            System.getenv().getOrDefault("VSM_MONGO_URI", "mongodb://localhost:27017");
    public static final String MONGO_DATABASE =
            System.getenv().getOrDefault("VSM_MONGO_DATABASE", "vehicle_service");
}
