/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.vehicle.service;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
/**
 *
 * @author anjal
 */
public class DiagnosticSummariesFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(DiagnosticSummariesFrame.class.getName());

    /**
     * Creates new form DiagnosticSummariesFrame
     */
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;

    private DefaultTableModel model;
private javax.swing.JTable diagnosticTable;
private javax.swing.JTextArea diagnosticArea;

private java.util.List<Document> diagnosticDocuments =
        new java.util.ArrayList<>();

    public DiagnosticSummariesFrame() {

    

    createDiagnosticUI();

    setTitle("Diagnostic Summaries - MongoDB");

    setSize(1100, 700);

    setLocationRelativeTo(null);

    setDefaultCloseOperation(
            javax.swing.WindowConstants.DISPOSE_ON_CLOSE
    );

    initializeMongoDB();

    diagnosticArea.setText(
            "TEST: Loading diagnostic summaries..."
    );

    loadDiagnosticSummaries();
}

private void initializeMongoDB() {

    try {

        mongoClient = MongoClients.create(
                "mongodb://localhost:27017"
        );

        database = mongoClient.getDatabase(
                "vehicle_service"
        );

        collection = database.getCollection(
                "diagnostic_summaries"
        );

    } catch (Exception ex) {

        JOptionPane.showMessageDialog(
                this,
                "MongoDB ERROR:\n\n"
                + ex.getClass().getName()
                + "\n\n"
                + ex.getMessage(),
                "MongoDB Error",
                JOptionPane.ERROR_MESSAGE
        );

        ex.printStackTrace();
    }
}


    private void createDiagnosticUI() {

    getContentPane().setLayout(
            new java.awt.BorderLayout(10, 10)
    );

    // =========================
    // TITLE
    // =========================

    javax.swing.JLabel title =
            new javax.swing.JLabel("Diagnostic Summaries");

    title.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    28
            )
    );

    title.setBorder(
            javax.swing.BorderFactory.createEmptyBorder(
                    15, 15, 10, 15
            )
    );

    getContentPane().add(
            title,
            java.awt.BorderLayout.NORTH
    );

    // =========================
    // TABLE
    // =========================

    model = new DefaultTableModel(
            new Object[]{
                "Vehicle ID",
                "Registration",
                "Job Card",
                "Date",
                "Technician",
                "Overall Status"
            },
            0
    ) {
        @Override
        public boolean isCellEditable(
                int row,
                int column
        ) {
            return false;
        }
    };

    diagnosticTable =
            new javax.swing.JTable(model);

    diagnosticTable.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.PLAIN,
                    13
            )
    );

    diagnosticTable.setRowHeight(28);

    diagnosticTable.getTableHeader().setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    13
            )
    );

    diagnosticTable.setSelectionMode(
            javax.swing.ListSelectionModel.SINGLE_SELECTION
    );

    javax.swing.JScrollPane tableScroll =
            new javax.swing.JScrollPane(
                    diagnosticTable
            );

    // =========================
    // DETAILS AREA
    // =========================

    diagnosticArea =
            new javax.swing.JTextArea();

    diagnosticArea.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.PLAIN,
                    14
            )
    );

    diagnosticArea.setEditable(false);
    diagnosticArea.setLineWrap(true);
    diagnosticArea.setWrapStyleWord(true);

    javax.swing.JScrollPane detailsScroll =
            new javax.swing.JScrollPane(
                    diagnosticArea
            );

    detailsScroll.setBorder(
            javax.swing.BorderFactory.createTitledBorder(
                    "Diagnostic Details"
            )
    );

    // =========================
    // SPLIT PANE
    // =========================

    javax.swing.JSplitPane splitPane =
            new javax.swing.JSplitPane(
                    javax.swing.JSplitPane.VERTICAL_SPLIT,
                    tableScroll,
                    detailsScroll
            );

    splitPane.setDividerLocation(280);
    splitPane.setResizeWeight(0.5);

    getContentPane().add(
            splitPane,
            java.awt.BorderLayout.CENTER
    );

    // =========================
    // TABLE SELECTION
    // =========================

    diagnosticTable.getSelectionModel()
            .addListSelectionListener(e -> {

                if (!e.getValueIsAdjusting()) {

                    int row =
                            diagnosticTable.getSelectedRow();

                    if (row >= 0 &&
                        row < diagnosticDocuments.size()) {

                        showDiagnosticDetails(
                                diagnosticDocuments.get(row)
                        );
                    }
                }
            });
}
    
   private void loadDiagnosticSummaries() {

    if (collection == null) {

        diagnosticArea.setText(
                "ERROR: MongoDB collection is NULL."
        );

        return;
    }

    try {

        model.setRowCount(0);
        diagnosticDocuments.clear();

        for (Document d : collection.find()) {

            diagnosticDocuments.add(d);

            String vehicleId =
                    String.valueOf(
                            d.get("vehicleId", "N/A")
                    );

            String registration =
                    String.valueOf(
                            d.get("registrationNo", "N/A")
                    );

            String jobCard =
                    String.valueOf(
                            d.get("jobCardNo", "N/A")
                    );

            String date =
                    String.valueOf(
                            d.get("diagnosticDate", "N/A")
                    );

            String technicianName = "N/A";

            Object technicianObj =
                    d.get("technician");

            if (technicianObj instanceof Document) {

                Document technician =
                        (Document) technicianObj;

                technicianName =
                        String.valueOf(
                                technician.get(
                                        "name",
                                        "N/A"
                                )
                        );
            }

            String overallStatus =
                    String.valueOf(
                            d.get(
                                    "overallStatus",
                                    "N/A"
                            )
                    );

            model.addRow(
                    new Object[]{
                        vehicleId,
                        registration,
                        jobCard,
                        date,
                        technicianName,
                        overallStatus
                    }
            );
        }

        if (model.getRowCount() == 0) {

            diagnosticArea.setText(
                    "No diagnostic summary records found."
            );

        } else {

            diagnosticArea.setText(
                    "Select a diagnostic summary from the table "
                    + "to view its details."
            );
        }

    } catch (Exception ex) {

        ex.printStackTrace();

        diagnosticArea.setText(
                "ERROR OCCURRED\n\n"
                + ex.getClass().getName()
                + "\n\n"
                + ex.getMessage()
        );
    }
}
   
   private void showDiagnosticDetails(Document d) {

    StringBuilder output =
            new StringBuilder();

    output.append("DIAGNOSTIC SUMMARY\n");
    output.append("==============================\n\n");

    output.append("Vehicle ID      : ")
            .append(String.valueOf(
                    d.get("vehicleId", "N/A")
            ))
            .append("\n");

    output.append("Registration No : ")
            .append(String.valueOf(
                    d.get("registrationNo", "N/A")
            ))
            .append("\n");

    output.append("Job Card No     : ")
            .append(String.valueOf(
                    d.get("jobCardNo", "N/A")
            ))
            .append("\n");

    output.append("Diagnostic Date : ")
            .append(String.valueOf(
                    d.get("diagnosticDate", "N/A")
            ))
            .append("\n");

    // Technician

    Object technicianObj =
            d.get("technician");

    output.append("Technician      : ");

    if (technicianObj instanceof Document) {

        Document technician =
                (Document) technicianObj;

        output.append(
                String.valueOf(
                        technician.get(
                                "name",
                                "N/A"
                        )
                )
        );

    } else {

        output.append("N/A");
    }

    output.append("\n\n");

    // Diagnostics

    output.append("DIAGNOSTIC RESULTS\n");
    output.append("==============================\n\n");

    Object diagnosticsObj =
            d.get("diagnostics");

    if (diagnosticsObj instanceof java.util.List) {

        java.util.List<?> diagnostics =
                (java.util.List<?>) diagnosticsObj;

        for (Object item : diagnostics) {

            if (item instanceof Document) {

                Document diagnostic =
                        (Document) item;

                output.append("System  : ")
                        .append(String.valueOf(
                                diagnostic.get(
                                        "system",
                                        "N/A"
                                )
                        ))
                        .append("\n");

                output.append("Status  : ")
                        .append(String.valueOf(
                                diagnostic.get(
                                        "status",
                                        "N/A"
                                )
                        ))
                        .append("\n");

                output.append("Details : ")
                        .append(String.valueOf(
                                diagnostic.get(
                                        "details",
                                        "N/A"
                                )
                        ))
                        .append("\n\n");
            }
        }
    }

    output.append("------------------------------\n");

    output.append("Overall Status : ")
            .append(String.valueOf(
                    d.get(
                            "overallStatus",
                            "N/A"
                    )
            ))
            .append("\n\n");

    output.append("Recommendation : ")
            .append(String.valueOf(
                    d.get(
                            "recommendation",
                            "N/A"
                    )
            ))
            .append("\n");

    diagnosticArea.setText(
            output.toString()
    );

    diagnosticArea.setCaretPosition(0);
}
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new DiagnosticSummariesFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
