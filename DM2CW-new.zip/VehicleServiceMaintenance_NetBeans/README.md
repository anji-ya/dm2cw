# Vehicle Service & Maintenance Management System
## Java Swing + Oracle + MongoDB + NetBeans

This project is designed for the NIBM Data Management 2 CW1 Option 3 scenario.

The assessment requires a Web or Enterprise Application using Oracle and MongoDB. For Option 3, Oracle stores customer details, vehicle registration information, service bookings, invoices/payments and spare part inventory; MongoDB stores vehicle job cards, technician notes, service history logs, customer complaints/feedback and diagnostic data summaries.

## 1. Technology
- Java 17
- NetBeans
- Maven
- Java Swing
- Oracle Database
- MongoDB

## 2. Project opening
1. Install JDK 17.
2. Install NetBeans.
3. Start Oracle Database and MongoDB.
4. In NetBeans choose File > Open Project and select this folder.
5. NetBeans should recognize it as a Maven project.
6. Build and run.

## 3. Oracle setup
The Java project defaults to:
- URL: jdbc:oracle:thin:@localhost:1521/FREEPDB1
- User: VSM_APP
- Password: VSM_APP

If you use Oracle XE, change DBConfig.java to XEPDB1.

Run:
1. database/oracle/01_schema.sql
2. Reconnect as VSM_APP
3. database/oracle/02_plsql.sql
4. database/oracle/03_seed.sql
5. database/oracle/04_queries.sql

Important:
The CREATE USER part of 01_schema.sql must be executed by SYS/SYSTEM. The remaining table/procedure scripts must be run while connected as VSM_APP.

## 4. MongoDB setup
Open mongosh and run:
database/mongodb/01_collections.js

Default Java connection:
mongodb://localhost:27017
Database:
vehicle_service

If your MongoDB has authentication, set environment variable VSM_MONGO_URI or edit DBConfig.java.

## 5. Login
The application has a demo login:
- Username: admin
- Password: admin123

The login screen also has a database connection test. The demo login works without requiring an Oracle user row, so you can first verify the GUI and then connect the databases.

## 6. Application screens
Oracle:
- Customers
- Vehicles
- Service Bookings
- Invoices & Payments
- Spare Parts

MongoDB:
- Vehicle Job Cards
- Technician Notes
- Service History
- Complaints & Feedback
- Diagnostics

Dashboard:
- Oracle/MongoDB connection status
- Record counters
- System module overview

## 7. Oracle-MongoDB integration design
Oracle is the system of record for structured transactional entities. MongoDB is used for flexible documents where technicians may record different fields for different services.

The logical link is:
Oracle vehicles.vehicle_id + vehicles.registration_no
    -> MongoDB vehicle_id + registration_no

The application performs the cross-database relationship at the service layer. No foreign key is attempted between Oracle and MongoDB.

For consistency:
- Create the Oracle vehicle/customer first.
- Use the Oracle vehicle_id in MongoDB documents.
- Use registration_no as a human-readable secondary identifier.
- Treat Oracle booking/invoice data as transactional.
- Log MongoDB changes with timestamps.
- For critical multi-step operations, use application-level compensation/retry and idempotent document identifiers.

## 8. Backup and recovery discussion
Oracle:
- RMAN full/incremental backups
- archived redo logs
- scheduled logical exports with Data Pump
- regular restore testing

MongoDB:
- mongodump/mongorestore
- replica set for availability where required
- scheduled backups and restore tests

The final presentation should explain that Oracle and MongoDB do not share a single ACID transaction in this architecture, so consistency is maintained through application orchestration, stable IDs, validation, retry and audit logging.

## 9. Assessment mapping
Learning outcomes in the brief include Oracle fundamentals, PL/SQL techniques, Oracle administration and NoSQL use.

The project includes:
- Oracle relational schema
- PK/FK/UNIQUE/CHECK constraints
- indexes
- PL/SQL procedures
- PL/SQL function
- cursor
- triggers
- MongoDB collections
- MongoDB JSON schema validation
- Java application integration
- realistic seed data

## 10. Common Oracle listener error
If you see ORA-12505, the listener does not recognize the SID/service in the connection string. Check the service name in Oracle and use:
jdbc:oracle:thin:@localhost:1521/FREEPDB1
or
jdbc:oracle:thin:@localhost:1521/XEPDB1

Do not use an arbitrary SID. The database service must actually exist.

## 11. Common MongoDB issue
If the application says MongoDB is not connected:
- confirm MongoDB service is running
- test `mongosh`
- test `mongodb://localhost:27017`
- if authentication is enabled, put the complete authenticated URI into VSM_MONGO_URI.

## 12. Viva points
Why Oracle?
- strong relationships, constraints, transactions and financial data integrity.

Why MongoDB?
- flexible service notes, diagnostics and logs can have changing structures.

How are they linked?
- shared vehicle_id and registration_no, coordinated by the Java application.

How is consistency maintained?
- Oracle is the transactional source; MongoDB documents use the same stable Oracle vehicle identifiers; validation and application-level retry/audit logic handle cross-database operations.

Why indexes?
- faster lookup by customer, vehicle, booking date and part code.

Why procedures?
- centralized business operations, reusable database logic and reduced repeated SQL in the application.

## 13. If NetBeans reports the two compile errors from the original ZIP
The corrected project now includes:
- `DashboardFrame.java`: the connection dialog uses the four-argument `JOptionPane.showMessageDialog`.
- `OracleCrudFrame.java`: booking dates explicitly use `java.sql.Date.valueOf(...)`.

If you already extracted the earlier ZIP, replace these two Java files with the corrected versions from this fixed ZIP.
